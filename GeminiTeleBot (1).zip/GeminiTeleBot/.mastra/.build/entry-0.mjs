import { Mastra } from '@mastra/core';
import { MastraError } from '@mastra/core/error';
import { PinoLogger } from '@mastra/loggers';
import { MastraLogger, LogLevel } from '@mastra/core/logger';
import pino from 'pino';
import { MCPServer } from '@mastra/mcp';
import { Inngest, NonRetriableError } from 'inngest';
import { z } from 'zod';
import { PostgresStore } from '@mastra/pg';
import { realtimeMiddleware } from '@inngest/realtime';
import { InngestWorkflow, init } from '@mastra/inngest';
import { registerApiRoute as registerApiRoute$1 } from '@mastra/core/server';
import { serve } from 'inngest/hono';
import { Agent } from '@mastra/core/agent';
import { Memory } from '@mastra/memory';
import { createOpenAI } from '@ai-sdk/openai';
import { createTool } from '@mastra/core/tools';
import require$$0 from 'crypto';
import require$$1 from 'fs';
import require$$2 from 'path';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { Pool } from 'pg';
import { relations, sql, eq, desc, count } from 'drizzle-orm';
import { drizzle } from 'drizzle-orm/node-postgres';
import { pgTable, timestamp, text, serial, date, integer } from 'drizzle-orm/pg-core';

const sharedPostgresStorage = new PostgresStore({
  connectionString: process.env.DATABASE_URL || "postgresql://localhost:5432/mastra"
});

const inngest = new Inngest(
  process.env.NODE_ENV === "production" ? {
    id: "replit-agent-workflow",
    name: "Replit Agent Workflow System"
  } : {
    id: "mastra",
    baseUrl: "http://localhost:3000",
    isDev: true,
    middleware: [realtimeMiddleware()]
  }
);

const {
  createWorkflow: originalCreateWorkflow,
  createStep} = init(inngest);
function createWorkflow(params) {
  return originalCreateWorkflow({
    ...params,
    retryConfig: {
      attempts: 3,
      ...params.retryConfig ?? {}
    }
  });
}
const inngestFunctions = [];
function registerApiRoute(...args) {
  const [path, options] = args;
  if (path.startsWith("/api/") || typeof options !== "object") {
    return registerApiRoute$1(...args);
  }
  inngestFunctions.push(
    inngest.createFunction(
      {
        id: `api-${path.replace(/^\/+/, "").replaceAll(/\/+/g, "-")}`,
        name: path
      },
      {
        event: `event/api.${path.replace(/^\/+/, "").replaceAll(/\/+/g, ".")}`
      },
      async ({ event, step }) => {
        await step.run("forward request to Mastra", async () => {
          const response = await fetch(`http://localhost:5000${path}`, {
            method: event.data.method,
            headers: event.data.headers,
            body: event.data.body
          });
          if (!response.ok) {
            if (response.status >= 500 && response.status < 600 || response.status == 429 || response.status == 408) {
              throw new Error(
                `Failed to forward request to Mastra: ${response.statusText}`
              );
            } else {
              throw new NonRetriableError(
                `Failed to forward request to Mastra: ${response.statusText}`
              );
            }
          }
        });
      }
    )
  );
  return registerApiRoute$1(...args);
}
function inngestServe({
  mastra,
  inngest: inngest2
}) {
  const wfs = mastra.getWorkflows();
  const functions = /* @__PURE__ */ new Set();
  for (const wf of Object.values(wfs)) {
    if (!(wf instanceof InngestWorkflow)) {
      continue;
    }
    wf.__registerMastra(mastra);
    for (const f of wf.getFunctions()) {
      functions.add(f);
    }
  }
  for (const fn of inngestFunctions) {
    functions.add(fn);
  }
  let serveHost = void 0;
  if (process.env.NODE_ENV === "production") {
    if (process.env.REPLIT_DOMAINS) {
      serveHost = `https://${process.env.REPLIT_DOMAINS.split(",")[0]}`;
    }
  } else {
    serveHost = "http://localhost:5000";
  }
  return serve({
    client: inngest2,
    functions: Array.from(functions),
    serveHost
  });
}

const multimodalTool = createTool({
  id: "multimodal-processor",
  description: "Process text messages and images (1-4 photos) using Google Gemini 2.5 Flash Image Preview AI via hubai.loe.gg. Can analyze images, answer questions about them, and handle mixed text+image content.",
  inputSchema: z.object({
    message: z.string().describe("The text message from the user"),
    imageUrls: z.array(z.string()).optional().describe("Array of image URLs to process (max 4 images)"),
    chatId: z.string().describe("Telegram chat ID for context"),
    userName: z.string().optional().describe("Username of the person sending the message")
  }),
  outputSchema: z.object({
    response: z.string().describe("The AI-generated response to the user"),
    processedImages: z.number().describe("Number of images that were processed")
  }),
  execute: async ({ context: { message, imageUrls, chatId, userName }, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [MultimodalTool] Starting execution", {
      message: message.substring(0, 100),
      imageCount: imageUrls?.length || 0,
      chatId,
      userName
    });
    try {
      const { createOpenAI } = await import('@ai-sdk/openai');
      const { generateText } = await import('ai');
      if (!process.env.HUBAI_API_KEY) {
        throw new Error("HUBAI_API_KEY not found in environment variables");
      }
      logger?.info("\u{1F4DD} [MultimodalTool] Using hubai.loe.gg API key:", { keyPrefix: process.env.HUBAI_API_KEY.substring(0, 10) + "..." });
      const openai = createOpenAI({
        apiKey: process.env.HUBAI_API_KEY,
        baseURL: "https://hubai.loe.gg/v1"
      });
      logger?.info("\u{1F4DD} [MultimodalTool] Initialized Gemini 2.5 Flash Image Preview via hubai.loe.gg");
      const content = [];
      if (message && message.trim()) {
        content.push({ type: "text", text: message });
        logger?.info("\u{1F4DD} [MultimodalTool] Added text message to request");
      }
      let processedImageCount = 0;
      if (imageUrls && imageUrls.length > 0) {
        logger?.info("\u{1F4DD} [MultimodalTool] Processing images", { count: imageUrls.length });
        const limitedImageUrls = imageUrls.slice(0, 4);
        for (const imageUrl of limitedImageUrls) {
          try {
            logger?.info("\u{1F4DD} [MultimodalTool] Downloading image", { url: imageUrl });
            const response = await fetch(imageUrl);
            if (!response.ok) {
              logger?.warn("\u26A0\uFE0F [MultimodalTool] Failed to download image", {
                url: imageUrl,
                status: response.status
              });
              continue;
            }
            const imageBuffer = await response.arrayBuffer();
            const base64Image = Buffer.from(imageBuffer).toString("base64");
            let mimeType = response.headers.get("content-type") || "image/jpeg";
            if (!mimeType.startsWith("image/")) {
              mimeType = "image/jpeg";
            }
            content.push({
              type: "image_url",
              image_url: {
                url: `data:${mimeType};base64,${base64Image}`
              }
            });
            processedImageCount++;
            logger?.info("\u2705 [MultimodalTool] Successfully processed image", {
              url: imageUrl,
              mimeType,
              size: imageBuffer.byteLength
            });
          } catch (error) {
            logger?.error("\u274C [MultimodalTool] Error processing image", {
              url: imageUrl,
              error: error instanceof Error ? error.message : String(error)
            });
          }
        }
      }
      if (content.length === 0) {
        content.push({ type: "text", text: "\u041F\u0440\u0438\u0432\u0435\u0442! \u041A\u0430\u043A \u0434\u0435\u043B\u0430?" });
      }
      logger?.info("\u{1F4DD} [MultimodalTool] Sending request to Gemini via hubai.loe.gg", {
        contentCount: content.length,
        processedImages: processedImageCount
      });
      const result = await generateText({
        model: openai("gemini-2.5-flash-image-preview"),
        messages: [
          {
            role: "user",
            content
          }
        ],
        temperature: 0.7
      });
      logger?.info("\u2705 [MultimodalTool] Generated response", {
        responseLength: result.text.length,
        processedImages: processedImageCount
      });
      return {
        response: result.text,
        processedImages: processedImageCount
      };
    } catch (error) {
      logger?.error("\u274C [MultimodalTool] Error during processing", {
        error: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : void 0
      });
      return {
        response: `\u0418\u0437\u0432\u0438\u043D\u0438\u0442\u0435, \u043F\u0440\u043E\u0438\u0437\u043E\u0448\u043B\u0430 \u043E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0435 \u0432\u0430\u0448\u0435\u0433\u043E \u0437\u0430\u043F\u0440\u043E\u0441\u0430. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0435 \u0440\u0430\u0437.`,
        processedImages: 0
      };
    }
  }
});

const users = pgTable("users", {
  user_id: text("user_id").primaryKey(),
  // Telegram user ID as string
  username: text("username").notNull(),
  daily_image_count: integer("daily_image_count").default(0).notNull(),
  last_reset_date: date("last_reset_date").defaultNow().notNull(),
  referral_code: text("referral_code").unique()
  // User's unique referral code
});
const image_generations = pgTable("image_generations", {
  id: serial("id").primaryKey(),
  user_id: text("user_id").notNull().references(() => users.user_id, { onDelete: "cascade" }),
  prompt: text("prompt").notNull(),
  image_url: text("image_url").notNull(),
  created_at: timestamp("created_at").defaultNow().notNull()
});
const referrals = pgTable("referrals", {
  id: serial("id").primaryKey(),
  referrer_user_id: text("referrer_user_id").notNull().references(() => users.user_id, { onDelete: "cascade" }),
  // Who invited
  referred_user_id: text("referred_user_id").notNull().references(() => users.user_id, { onDelete: "cascade" }),
  // Who was invited
  referral_code: text("referral_code").notNull().unique(),
  // Unique referral code
  created_at: timestamp("created_at").defaultNow().notNull()
});
const usersRelations = relations(users, ({ many }) => ({
  image_generations: many(image_generations),
  referrals_made: many(referrals, { relationName: "referrer" }),
  // Referrals user made
  referrals_received: many(referrals, { relationName: "referred" })
  // Referrals user received from
}));
const image_generationsRelations = relations(
  image_generations,
  ({ one }) => ({
    user: one(users, {
      fields: [image_generations.user_id],
      references: [users.user_id]
    })
  })
);
const referralsRelations = relations(referrals, ({ one }) => ({
  referrer: one(users, {
    fields: [referrals.referrer_user_id],
    references: [users.user_id],
    relationName: "referrer"
  }),
  referred: one(users, {
    fields: [referrals.referred_user_id],
    references: [users.user_id],
    relationName: "referred"
  })
}));

var schema = /*#__PURE__*/Object.freeze({
  __proto__: null,
  image_generations: image_generations,
  image_generationsRelations: image_generationsRelations,
  referrals: referrals,
  referralsRelations: referralsRelations,
  users: users,
  usersRelations: usersRelations
});

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || "postgresql://localhost:5432/mastra",
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
});
const db = drizzle(pool, { schema });
async function upsertUser(userId, username) {
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [user] = await db.insert(users).values({
    user_id: userId,
    username,
    daily_image_count: 0,
    last_reset_date: today
  }).onConflictDoUpdate({
    target: users.user_id,
    set: {
      username,
      // Reset daily count if it's a new day
      daily_image_count: sql`
          CASE 
            WHEN ${users.last_reset_date} < ${today}
            THEN 0
            ELSE ${users.daily_image_count}
          END
        `,
      last_reset_date: sql`
          CASE 
            WHEN ${users.last_reset_date} < ${today}
            THEN ${today}
            ELSE ${users.last_reset_date}
          END
        `
    }
  }).returning();
  return user;
}
async function getUserDailyCount(userId) {
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [user] = await db.select().from(users).where(eq(users.user_id, userId));
  if (!user) {
    return 0;
  }
  if (user.last_reset_date !== today) {
    await db.update(users).set({
      daily_image_count: 0,
      last_reset_date: today
    }).where(eq(users.user_id, userId));
    return 0;
  }
  return user.daily_image_count;
}
async function incrementUserImageCount(userId) {
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [updatedUser] = await db.update(users).set({
    daily_image_count: sql`${users.daily_image_count} + 1`,
    last_reset_date: today
  }).where(eq(users.user_id, userId)).returning();
  return updatedUser;
}
async function saveImageGeneration(userId, prompt, imageUrl) {
  const [generation] = await db.insert(image_generations).values({
    user_id: userId,
    prompt,
    image_url: imageUrl
  }).returning();
  return generation;
}
async function getUserImageHistory(userId, limit = 20) {
  const generations = await db.select().from(image_generations).where(eq(image_generations.user_id, userId)).orderBy(desc(image_generations.created_at)).limit(limit);
  return generations;
}
const ADMIN_USERS = ["6913446846"];
function isAdminUser(userId) {
  return ADMIN_USERS.includes(userId);
}
async function hasReachedDailyLimit(userId) {
  if (isAdminUser(userId)) {
    return false;
  }
  const dailyCount = await getUserDailyCount(userId);
  return dailyCount >= 3;
}

const geminiImageGenerationTool = createTool({
  id: "gemini-image-generation-tool",
  description: "Generate images using Google Gemini 2.5 Flash Image Preview via hubai.loe.gg. Supports both text-to-image and image-to-image generation. Premium quality, use source_images for image-to-image generation.",
  inputSchema: z.object({
    prompt: z.string().describe("Description of the image to generate (in any language)"),
    user_id: z.string().describe("Telegram user ID for tracking"),
    chat_id: z.string().describe("Telegram chat ID for context"),
    username: z.string().optional().describe("Telegram username for display"),
    source_images: z.array(z.string()).optional().describe("URLs of source images for image-to-image generation (max 4 images)")
  }),
  outputSchema: z.object({
    success: z.boolean().describe("Whether image generation was successful"),
    image_base64: z.string().optional().describe("Base64 encoded image data (without data URI prefix)"),
    message: z.string().describe("Status message for the user"),
    daily_count: z.number().describe("Always 0 - no limits"),
    limit_reached: z.boolean().describe("Always false - no limits")
  }),
  execute: async ({ context: { prompt, user_id, chat_id, username, source_images }, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [GeminiImageGenerationTool] Starting image generation with Gemini 2.5 Flash Image Preview", {
      prompt: prompt.substring(0, 50) + "...",
      user_id,
      chat_id,
      username,
      source_images_count: source_images?.length || 0,
      generation_type: source_images?.length ? "image-to-image" : "text-to-image"
    });
    try {
      const { createOpenAI } = await import('@ai-sdk/openai');
      await import('ai');
      if (!process.env.HUBAI_API_KEY) {
        logger?.error("\u274C [GeminiImageGenerationTool] No HUBAI_API_KEY found in environment");
        return {
          success: false,
          message: "\u274C \u0421\u0435\u0440\u0432\u0438\u0441 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0439 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D. API \u043A\u043B\u044E\u0447 \u043D\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043D.",
          daily_count: 0,
          limit_reached: false
        };
      }
      logger?.info("\u{1F4DD} [GeminiImageGenerationTool] Using hubai.loe.gg API");
      const openai = createOpenAI({
        baseURL: "https://hubai.loe.gg/v1",
        apiKey: process.env.HUBAI_API_KEY
      });
      logger?.info("\u{1F4DD} [GeminiImageGenerationTool] Upserting user in database");
      await upsertUser(user_id, username || `user_${user_id}`);
      logger?.info("\u{1F4DD} [GeminiImageGenerationTool] Checking daily limits");
      const isAdmin = isAdminUser(user_id);
      const limitReached = await hasReachedDailyLimit(user_id);
      if (limitReached && !isAdmin) {
        logger?.warn("\u26A0\uFE0F [GeminiImageGenerationTool] User reached daily limit", { user_id });
        return {
          success: false,
          message: "\u{1F6AB} \u041F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u0434\u043D\u0435\u0432\u043D\u043E\u0439 \u043B\u0438\u043C\u0438\u0442 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0437\u0430\u0432\u0442\u0440\u0430!",
          daily_count: 15,
          limit_reached: true
        };
      }
      if (isAdmin) {
        logger?.info("\u{1F451} [GeminiImageGenerationTool] Admin user detected - unlimited access", { user_id });
      }
      logger?.info("\u{1F4DD} [GeminiImageGenerationTool] Generating image with Gemini 2.5 Flash Image Preview", {
        prompt: prompt.substring(0, 100) + "...",
        source_images_count: source_images?.length || 0
      });
      const content = [];
      if (source_images && source_images.length > 0) {
        logger?.info("\u{1F4DD} [GeminiImageGenerationTool] Processing source images for image-to-image generation");
        const limitedImages = source_images.slice(0, 4);
        for (const imageUrl2 of limitedImages) {
          try {
            logger?.info("\u{1F4DD} [GeminiImageGenerationTool] Downloading source image", { url: imageUrl2 });
            const response = await fetch(imageUrl2);
            if (!response.ok) {
              logger?.warn("\u26A0\uFE0F [GeminiImageGenerationTool] Failed to download source image", {
                url: imageUrl2,
                status: response.status
              });
              continue;
            }
            const imageBuffer = await response.arrayBuffer();
            const base64Image = Buffer.from(imageBuffer).toString("base64");
            let mimeType = response.headers.get("content-type") || "image/jpeg";
            if (!mimeType.startsWith("image/")) {
              mimeType = "image/jpeg";
            }
            content.push({
              type: "image_url",
              image_url: {
                url: `data:${mimeType};base64,${base64Image}`
              }
            });
            logger?.info("\u2705 [GeminiImageGenerationTool] Successfully processed source image", {
              url: imageUrl2,
              mimeType,
              size: imageBuffer.byteLength
            });
          } catch (error) {
            logger?.error("\u274C [GeminiImageGenerationTool] Error processing source image", {
              url: imageUrl2,
              error: error instanceof Error ? error.message : String(error)
            });
          }
        }
      }
      const isImageToImage = source_images && source_images.length > 0;
      const generationInstruction = isImageToImage ? `Based on the provided source image(s), generate a new high-quality image following this description: ${prompt}. 
           Use the source image(s) as inspiration for style, composition, or content, but create a new unique image according to the prompt.
           The result should be visually appealing and maintain good composition and lighting.` : `Generate a high-quality image based on this description: ${prompt}. 
           Please create a detailed, visually appealing image that matches the description accurately.
           The image should be suitable for sharing and have excellent composition and lighting.`;
      content.push({
        type: "text",
        text: `${generationInstruction} Return the result as a base64-encoded image.`
      });
      const { generateText } = await import('ai');
      const result = await generateText({
        model: openai("gemini-2.5-flash-image-preview"),
        messages: [
          {
            role: "user",
            content
          }
        ],
        maxTokens: 4096,
        temperature: 0.8
      });
      let imageBase64 = "";
      let imageDescription = "";
      const base64Patterns = [
        /data:image\/[^;]+;base64,([A-Za-z0-9+/=]+)/g,
        /base64:([A-Za-z0-9+/=]+)/g,
        /([A-Za-z0-9+/=]{100,})/g
        // Длинная строка base64
      ];
      for (const pattern of base64Patterns) {
        const match = result.text.match(pattern);
        if (match) {
          imageBase64 = match[0].includes(",") ? match[0].split(",")[1] : match[1] || match[0];
          imageDescription = isImageToImage ? `\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0441\u043E\u0437\u0434\u0430\u043D\u043E \u043D\u0430 \u043E\u0441\u043D\u043E\u0432\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u043D\u043E\u0433\u043E \u0444\u043E\u0442\u043E: ${prompt}` : `\u0421\u0433\u0435\u043D\u0435\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0435 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435: ${prompt}`;
          break;
        }
      }
      if (!imageBase64 || imageBase64.length < 100) {
        logger?.error("\u274C [GeminiImageGenerationTool] No valid image data in response", {
          responseLength: result.text.length,
          responseSample: result.text.substring(0, 200)
        });
        return {
          success: false,
          message: isImageToImage ? "\u274C \u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u0433\u0435\u043D\u0435\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u043D\u0430 \u043E\u0441\u043D\u043E\u0432\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u043D\u043E\u0433\u043E \u0444\u043E\u0442\u043E. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0434\u0440\u0443\u0433\u043E\u0435 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0438\u043B\u0438 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435." : "\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0435 \u0440\u0430\u0437 \u0441 \u0434\u0440\u0443\u0433\u0438\u043C \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435\u043C.",
          daily_count: 0,
          limit_reached: false
        };
      }
      logger?.info("\u2705 [GeminiImageGenerationTool] Image generated successfully", {
        imageDataLength: imageBase64.length,
        description: imageDescription
      });
      const imageUrl = `hubai://gemini-2.5-flash-image-preview/${Date.now()}-${user_id}`;
      logger?.info("\u{1F4DD} [GeminiImageGenerationTool] Saving generation record to database");
      await saveImageGeneration(user_id, prompt, imageUrl);
      logger?.info("\u2705 [GeminiImageGenerationTool] Image generation completed successfully", {
        user_id,
        prompt: prompt.substring(0, 50) + "...",
        imageSize: imageBase64.length
      });
      const successMessage = isImageToImage ? `\u2705 \u041D\u043E\u0432\u043E\u0435 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0441\u043E\u0437\u0434\u0430\u043D\u043E \u043D\u0430 \u043E\u0441\u043D\u043E\u0432\u0435 \u0432\u0430\u0448\u0435\u0433\u043E \u0444\u043E\u0442\u043E! ${imageDescription}` : `\u2705 \u0413\u043E\u0442\u043E\u0432\u043E! ${imageDescription || "\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0441\u0433\u0435\u043D\u0435\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043E."}`;
      return {
        success: true,
        image_base64: imageBase64,
        message: successMessage,
        daily_count: 0,
        // Счетчик теперь управляется в workflow step2
        limit_reached: false
      };
    } catch (error) {
      logger?.error("\u274C [GeminiImageGenerationTool] Error during image generation", {
        error: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : void 0,
        user_id,
        prompt: prompt.substring(0, 50) + "..."
      });
      if (error instanceof Error) {
        const errorMessage = error.message.toLowerCase();
        if (errorMessage.includes("rate limit") || errorMessage.includes("quota")) {
          return {
            success: false,
            message: "\u23F1\uFE0F API \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043F\u0435\u0440\u0435\u0433\u0440\u0443\u0436\u0435\u043D. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0447\u0435\u0440\u0435\u0437 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0441\u0435\u043A\u0443\u043D\u0434.",
            daily_count: 0,
            limit_reached: false
          };
        }
        if (errorMessage.includes("content policy") || errorMessage.includes("safety")) {
          return {
            success: false,
            message: "\u{1F6E1}\uFE0F \u0412\u0430\u0448 \u0437\u0430\u043F\u0440\u043E\u0441 \u043D\u0430\u0440\u0443\u0448\u0430\u0435\u0442 \u043F\u0440\u0430\u0432\u0438\u043B\u0430 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435.",
            daily_count: 0,
            limit_reached: false
          };
        }
        if (errorMessage.includes("invalid") || errorMessage.includes("unauthorized")) {
          return {
            success: false,
            message: "\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u0438 API. \u041E\u0431\u0440\u0430\u0442\u0438\u0442\u0435\u0441\u044C \u043A \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u0443.",
            daily_count: 0,
            limit_reached: false
          };
        }
      }
      return {
        success: false,
        message: "\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438, \u043E\u0431\u0440\u0430\u0442\u0438\u0442\u0435\u0441\u044C \u043A @dmitriy_ferixdi",
        daily_count: 0,
        limit_reached: false
      };
    }
  }
});

const subscriptionCheckTool = createTool({
  id: "subscription-check-tool",
  description: "Check if a Telegram user is subscribed to the @ferixdi_ai channel using Telegram Bot API. Returns subscription status for access control.",
  inputSchema: z.object({
    user_id: z.string().describe("Telegram user ID to check subscription status for")
  }),
  outputSchema: z.object({
    is_subscribed: z.boolean().describe("Whether the user is subscribed to the channel"),
    status: z.string().describe("User's membership status (member, administrator, creator, left, kicked, or restricted)"),
    message: z.string().describe("Human-readable message about subscription status"),
    channel: z.string().describe("Channel username that was checked")
  }),
  execute: async ({ context: { user_id }, mastra }) => {
    const logger = mastra?.getLogger();
    const channelUsername = "@ferixdi_ai";
    logger?.info("\u{1F527} [SubscriptionCheckTool] Checking subscription status", {
      user_id,
      channel: channelUsername
    });
    try {
      if (!process.env.TELEGRAM_BOT_TOKEN) {
        logger?.error("\u274C [SubscriptionCheckTool] TELEGRAM_BOT_TOKEN not found in environment");
        return {
          is_subscribed: false,
          status: "unknown",
          message: "\u274C \u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0443. \u0421\u0435\u0440\u0432\u0438\u0441 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D.",
          channel: channelUsername
        };
      }
      logger?.info("\u{1F4DD} [SubscriptionCheckTool] Making API request to Telegram");
      const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
      const response = await fetch(`${telegramApiUrl}/getChatMember`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          chat_id: channelUsername,
          user_id: parseInt(user_id)
        })
      });
      const result = await response.json();
      logger?.info("\u{1F4DD} [SubscriptionCheckTool] Received API response", {
        ok: result.ok,
        status: result.result?.status,
        error_code: result.error_code,
        description: result.description
      });
      if (!result.ok) {
        logger?.warn("\u26A0\uFE0F [SubscriptionCheckTool] API request failed", {
          error_code: result.error_code,
          description: result.description
        });
        if (result.error_code === 400 && result.description?.includes("user not found")) {
          return {
            is_subscribed: false,
            status: "not_found",
            message: "\u274C \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0432 \u043A\u0430\u043D\u0430\u043B\u0435.",
            channel: channelUsername
          };
        }
        if (result.error_code === 400 && result.description?.includes("chat not found")) {
          return {
            is_subscribed: false,
            status: "channel_not_found",
            message: "\u274C \u041A\u0430\u043D\u0430\u043B \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438.",
            channel: channelUsername
          };
        }
        return {
          is_subscribed: false,
          status: "error",
          message: "\u274C \u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0443. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u043F\u043E\u0437\u0436\u0435.",
          channel: channelUsername
        };
      }
      const memberStatus = result.result?.status;
      logger?.info("\u{1F4DD} [SubscriptionCheckTool] User membership status", {
        user_id,
        status: memberStatus
      });
      const subscribedStatuses = ["member", "administrator", "creator"];
      const isSubscribed = subscribedStatuses.includes(memberStatus);
      let message = "";
      switch (memberStatus) {
        case "member":
          message = "\u2705 \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u043F\u043E\u0434\u043F\u0438\u0441\u0430\u043D \u043D\u0430 \u043A\u0430\u043D\u0430\u043B.";
          break;
        case "administrator":
          message = "\u2705 \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u043E\u043C \u043A\u0430\u043D\u0430\u043B\u0430.";
          break;
        case "creator":
          message = "\u2705 \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u0441\u043E\u0437\u0434\u0430\u0442\u0435\u043B\u0435\u043C \u043A\u0430\u043D\u0430\u043B\u0430.";
          break;
        case "left":
          message = "\u274C \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u043F\u043E\u043A\u0438\u043D\u0443\u043B \u043A\u0430\u043D\u0430\u043B. \u041F\u043E\u0434\u043F\u0438\u0448\u0438\u0442\u0435\u0441\u044C \u043D\u0430 @ferixdi_ai \u0434\u043B\u044F \u0434\u043E\u0441\u0442\u0443\u043F\u0430.";
          break;
        case "kicked":
          message = "\u{1F6AB} \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D \u0432 \u043A\u0430\u043D\u0430\u043B\u0435.";
          break;
        case "restricted":
          message = "\u26A0\uFE0F \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D \u0432 \u043A\u0430\u043D\u0430\u043B\u0435.";
          break;
        default:
          message = "\u2753 \u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u0441\u0442\u0430\u0442\u0443\u0441 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0438.";
      }
      logger?.info("\u2705 [SubscriptionCheckTool] Subscription check completed", {
        user_id,
        is_subscribed: isSubscribed,
        status: memberStatus,
        channel: channelUsername
      });
      return {
        is_subscribed: isSubscribed,
        status: memberStatus,
        message,
        channel: channelUsername
      };
    } catch (error) {
      logger?.error("\u274C [SubscriptionCheckTool] Error during subscription check", {
        error: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : void 0,
        user_id,
        channel: channelUsername
      });
      return {
        is_subscribed: false,
        status: "error",
        message: "\u274C \u041F\u0440\u043E\u0438\u0437\u043E\u0448\u043B\u0430 \u043E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0435 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0438. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u043F\u043E\u0437\u0436\u0435.",
        channel: channelUsername
      };
    }
  }
});

createOpenAI({
  apiKey: process.env.HUBAI_API_KEY,
  baseURL: "https://hubai.loe.gg/v1"
});
const openai = createOpenAI({
  apiKey: process.env.OPENAI_API_KEY
});
const telegramBot = new Agent({
  name: "AI Image Generator Telegram Bot",
  instructions: `\u0422\u044B \u0431\u043E\u0442 Nano Banano \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0439 \u0447\u0435\u0440\u0435\u0437 Gemini 2.5 Flash Image Preview.

\u0412\u041E\u0417\u041C\u041E\u0416\u041D\u041E\u0421\u0422\u0418:
- \u{1F3A8} \u0413\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044F \u043F\u043E \u0442\u0435\u043A\u0441\u0442\u0443: \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 geminiImageGenerationTool
- \u{1F5BC}\uFE0F \u0413\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044F \u043F\u043E \u0444\u043E\u0442\u043E: \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 geminiImageGenerationTool \u0441 source_images
- \u{1F441}\uFE0F \u0410\u043D\u0430\u043B\u0438\u0437 \u0444\u043E\u0442\u043E: \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 multimodalTool

\u0420\u0410\u0411\u041E\u0422\u0410 \u0421 \u0418\u0417\u041E\u0411\u0420\u0410\u0416\u0415\u041D\u0418\u042F\u041C\u0418:
- \u0415\u0441\u043B\u0438 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u043F\u0440\u0438\u0441\u043B\u0430\u043B \u0444\u043E\u0442\u043E + \u0442\u0435\u043A\u0441\u0442 = \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 geminiImageGenerationTool \u0441 source_images
- \u0415\u0441\u043B\u0438 \u0442\u043E\u043B\u044C\u043A\u043E \u0442\u0435\u043A\u0441\u0442 = \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 geminiImageGenerationTool \u0431\u0435\u0437 source_images  
- \u0415\u0441\u043B\u0438 \u0442\u043E\u043B\u044C\u043A\u043E \u0444\u043E\u0442\u043E \u0438\u043B\u0438 \u0432\u043E\u043F\u0440\u043E\u0441 \u043E \u0444\u043E\u0442\u043E = \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 multimodalTool

\u041E\u0442\u0432\u0435\u0447\u0430\u0439 \u043A\u0440\u0430\u0442\u043A\u043E \u043F\u043E-\u0440\u0443\u0441\u0441\u043A\u0438.`,
  model: openai("gpt-4o"),
  tools: {
    multimodalTool,
    geminiImageGenerationTool,
    subscriptionCheckTool
  },
  memory: new Memory({
    options: {
      threads: {
        generateTitle: false
      },
      lastMessages: 2
    },
    storage: sharedPostgresStorage
  })
});

function isFileId(input) {
  return !input.startsWith("http") && !input.includes("/");
}
async function resolveFileId(fileId, logger) {
  try {
    if (!process.env.TELEGRAM_BOT_TOKEN) {
      logger?.error("\u{1F510} [TelegramFileResolver] TELEGRAM_BOT_TOKEN not found");
      return null;
    }
    logger?.info("\u{1F4C1} [TelegramFileResolver] Resolving file_id for local download", { fileId });
    const fileResponse = await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/getFile?file_id=${fileId}`);
    const fileData = await fileResponse.json();
    if (!fileData.ok || !fileData.result.file_path) {
      logger?.error("\u274C [TelegramFileResolver] Failed to get file info", {
        fileId,
        error: fileData.description || "Unknown error"
      });
      return null;
    }
    const fileUrl = `https://api.telegram.org/file/bot${process.env.TELEGRAM_BOT_TOKEN}/${fileData.result.file_path}`;
    const downloadResponse = await fetch(fileUrl);
    if (!downloadResponse.ok) {
      logger?.error("\u274C [TelegramFileResolver] Failed to download file", { fileId });
      return null;
    }
    const arrayBuffer = await downloadResponse.arrayBuffer();
    const base64 = Buffer.from(arrayBuffer).toString("base64");
    let mimeType = downloadResponse.headers.get("content-type") || "";
    if (!mimeType || mimeType === "application/octet-stream") {
      const buffer = Buffer.from(arrayBuffer);
      const signature = buffer.toString("hex", 0, 4).toUpperCase();
      logger?.debug("\u{1F50D} [TelegramFileResolver] Detecting MIME type by file signature", {
        signature,
        contentType: mimeType
      });
      if (signature.startsWith("FFD8FF")) {
        mimeType = "image/jpeg";
      } else if (signature.startsWith("89504E47")) {
        mimeType = "image/png";
      } else if (signature.startsWith("47494638")) {
        mimeType = "image/gif";
      } else if (signature.startsWith("52494646")) {
        const webpSignature = buffer.toString("ascii", 8, 12);
        if (webpSignature === "WEBP") {
          mimeType = "image/webp";
        } else {
          mimeType = "image/jpeg";
        }
      } else {
        mimeType = "image/jpeg";
      }
      logger?.info("\u2705 [TelegramFileResolver] MIME type detected by signature", {
        detectedMimeType: mimeType,
        originalContentType: downloadResponse.headers.get("content-type")
      });
    }
    logger?.info("\u2705 [TelegramFileResolver] File downloaded and converted to base64", {
      fileId,
      size: base64.length,
      mimeType
    });
    return `data:${mimeType};base64,${base64}`;
  } catch (error) {
    logger?.error("\u274C [TelegramFileResolver] Error resolving file_id", {
      fileId,
      error: error instanceof Error ? error.message : String(error)
    });
    return null;
  }
}
async function resolveImageUrls(inputs, logger) {
  const resolvedUrls = [];
  for (const input of inputs) {
    if (isFileId(input)) {
      const url = await resolveFileId(input, logger);
      if (url) {
        resolvedUrls.push(url);
      }
    } else {
      resolvedUrls.push(input);
    }
  }
  return resolvedUrls;
}

class HubaiGeminiGenerator {
  genAI = null;
  logger;
  apiKey;
  constructor(logger) {
    this.logger = logger;
    this.apiKey = process.env.HUBAI_API_KEY || "";
    if (!this.apiKey) {
      this.logger?.error("\u274C [HubaiGemini] No HUBAI_API_KEY found in environment variables");
      return;
    }
    try {
      this.logger?.info("\u{1F527} [HubaiGemini] Initializing for hubai.loe.gg API");
      this.genAI = new GoogleGenerativeAI(this.apiKey);
      this.logger?.info("\u2705 [HubaiGemini] Initialized for hubai.loe.gg direct API calls");
    } catch (error) {
      this.logger?.error("\u274C [HubaiGemini] Failed to initialize", {
        error: error instanceof Error ? error.message : String(error)
      });
      this.genAI = null;
    }
  }
  /**
   * Генерация изображения используя Google Generative AI SDK
   */
  async generateImage(request) {
    const { prompt, model = "gemini-2.5-flash-image-preview", sourceImages = [] } = request;
    this.logger?.info("\u{1F34C} [HubaiGemini] Starting image generation", {
      prompt: prompt.substring(0, 100) + (prompt.length > 100 ? "..." : ""),
      model,
      sourceImagesCount: sourceImages.length
    });
    const resolvedImageUrls = await resolveImageUrls(sourceImages, this.logger);
    const updatedRequest = { ...request, sourceImages: resolvedImageUrls };
    if (!this.genAI) {
      const errorMsg = "Google Generative AI client not initialized";
      this.logger?.error("\u274C [HubaiGemini] Client not initialized");
      return {
        success: false,
        error: errorMsg
      };
    }
    if (!this.apiKey) {
      const errorMsg = "HUBAI_API_KEY not found in environment variables";
      this.logger?.error("\u274C [HubaiGemini] API key missing");
      return {
        success: false,
        error: errorMsg
      };
    }
    try {
      this.logger?.info("\u{1F527} [HubaiGemini] Using direct hubai.loe.gg API call as primary method");
      const directResult = await this.tryDirectApiCall(updatedRequest);
      if (directResult.success) {
        return directResult;
      }
      this.logger?.info("\u{1F527} [HubaiGemini] Direct API call failed, trying Google SDK fallback");
      this.logger?.info("\u{1F527} [HubaiGemini] Getting model instance", { model });
      const geminiModel = this.genAI.getGenerativeModel({ model });
      const parts = [];
      if (updatedRequest.sourceImages && updatedRequest.sourceImages.length > 0) {
        this.logger?.info("\u{1F527} [HubaiGemini] Processing source images", {
          count: updatedRequest.sourceImages.length
        });
        for (const imageUrl of updatedRequest.sourceImages.slice(0, 4)) {
          try {
            const imageData = await this.fetchImageAsBase64(imageUrl);
            if (imageData) {
              parts.push({
                inlineData: {
                  data: imageData.base64,
                  mimeType: imageData.mimeType
                }
              });
              this.logger?.debug("\u2705 [HubaiGemini] Added source image", {
                mimeType: imageData.mimeType,
                size: imageData.base64.length
              });
            }
          } catch (error) {
            this.logger?.error("\u26A0\uFE0F [HubaiGemini] Failed to process source image", {
              imageUrl,
              error: error instanceof Error ? error.message : String(error)
            });
          }
        }
      }
      let enhancedPrompt;
      if (model === "gemini-2.0-flash-lite") {
        enhancedPrompt = `Generate an image: ${prompt}

Please create a high-quality, detailed image based on this description. The image should be visually appealing and match the provided description as closely as possible.

Style: High resolution, detailed, professional quality
Format: Return the generated image`;
      } else {
        enhancedPrompt = `Create a new image based on: ${prompt}

Generate a high-quality image that matches this description. 
${updatedRequest.sourceImages.length > 0 ? "Use the provided source images as reference or inspiration for the new image." : ""}
Make the image detailed, visually appealing, and professionally rendered.

Requirements:
- High quality and detailed
- Match the description provided
- Professional appearance
- Creative and visually appealing`;
      }
      parts.push({ text: enhancedPrompt });
      this.logger?.info("\u{1F527} [HubaiGemini] Calling generateContent with enhanced prompt", {
        model,
        partsCount: parts.length,
        hasSourceImages: updatedRequest.sourceImages.length > 0
      });
      const result = await geminiModel.generateContent(parts);
      const response = await result.response;
      this.logger?.info("\u{1F4DD} [HubaiGemini] Received response from model", {
        model,
        hasResponse: !!response
      });
      const imageBase64 = await this.extractImageFromResponse(response);
      if (imageBase64) {
        this.logger?.info("\u2705 [HubaiGemini] Successfully generated image via SDK fallback", {
          model,
          imageSize: imageBase64.length,
          prompt: prompt.substring(0, 50) + "..."
        });
        return {
          success: true,
          imageBase64,
          description: `Image generated using ${model} for: ${prompt.substring(0, 100)}${prompt.length > 100 ? "..." : ""}`
        };
      } else {
        return {
          success: false,
          error: "No valid image data found in any method"
        };
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.logger?.error("\u274C [HubaiGemini] Error during image generation", {
        error: errorMessage,
        model,
        prompt: prompt.substring(0, 50) + "..."
      });
      return {
        success: false,
        error: `Image generation failed: ${errorMessage}`
      };
    }
  }
  /**
   * Извлечение изображения из ответа модели
   */
  async extractImageFromResponse(response) {
    this.logger?.debug("\u{1F50D} [HubaiGemini] Extracting image from response");
    try {
      if (response.candidates && response.candidates[0]) {
        const candidate = response.candidates[0];
        if (candidate.content && candidate.content.parts) {
          for (const part of candidate.content.parts) {
            if (part.inline_data && part.inline_data.data) {
              this.logger?.debug("\u2705 [HubaiGemini] Found image in inline_data");
              return part.inline_data.data;
            }
            if (part.text) {
              const imageBase64 = this.extractBase64FromText(part.text);
              if (imageBase64) {
                this.logger?.debug("\u2705 [HubaiGemini] Found image in text part");
                return imageBase64;
              }
            }
          }
        }
      }
      const responseText = response.text ? await response.text() : "";
      if (responseText) {
        const imageBase64 = this.extractBase64FromText(responseText);
        if (imageBase64) {
          this.logger?.debug("\u2705 [HubaiGemini] Found image in response text");
          return imageBase64;
        }
      }
      this.logger?.debug("\u26A0\uFE0F [HubaiGemini] No image found in response");
      return null;
    } catch (error) {
      this.logger?.error("\u274C [HubaiGemini] Error extracting image from response", {
        error: error instanceof Error ? error.message : String(error)
      });
      return null;
    }
  }
  /**
   * Извлечение base64 данных из текста
   */
  extractBase64FromText(text) {
    const base64Patterns = [
      /data:image\/[^;]+;base64,([A-Za-z0-9+/=]+)/g,
      /base64:([A-Za-z0-9+/=]+)/g,
      /([A-Za-z0-9+/=]{100,})/g
    ];
    for (const pattern of base64Patterns) {
      const match = text.match(pattern);
      if (match && match[0]) {
        const imageBase64 = match[0].includes(",") ? match[0].split(",")[1] : match[1] || match[0];
        if (imageBase64 && imageBase64.length > 100) {
          return imageBase64;
        }
      }
    }
    return null;
  }
  /**
   * Прямой API вызов к hubai.loe.gg (основной метод)
   */
  async tryDirectApiCall(request) {
    const { model = "gemini-2.5-flash-image-preview", sourceImages = [] } = request;
    this.logger ? {
      info: this.logger.info.bind(this.logger),
      error: this.logger.error.bind(this.logger),
      debug: this.logger.debug.bind(this.logger),
      warn: this.logger.info.bind(this.logger)} : void 0;
    await resolveImageUrls(sourceImages, this.logger);
    this.logger?.info("\u{1F527} [HubaiGemini] Making direct API call to hubai.loe.gg", { model });
    try {
      const endpoints = [
        // Основной endpoint для генерации контента
        {
          url: `https://hubai.loe.gg/v1beta/models/${model}:generateContent`,
          method: "generateContent"
        },
        // Chat completions endpoint (как в оригинальном nanoBananoGenerator)
        {
          url: "https://hubai.loe.gg/v1/chat/completions",
          method: "chatCompletions"
        }
      ];
      for (const endpoint of endpoints) {
        try {
          this.logger?.info("\u{1F527} [HubaiGemini] Trying endpoint", {
            url: endpoint.url,
            method: endpoint.method
          });
          const result = await this.callEndpoint(endpoint, request);
          if (result.success) {
            return result;
          }
        } catch (error) {
          this.logger?.debug("\u26A0\uFE0F [HubaiGemini] Endpoint failed, trying next", {
            endpoint: endpoint.method,
            error: error instanceof Error ? error.message : String(error)
          });
          continue;
        }
      }
      this.logger?.error("\u274C [HubaiGemini] All direct API endpoints failed");
      return {
        success: false,
        error: "All direct API endpoints failed"
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.logger?.error("\u274C [HubaiGemini] Direct API call exception", {
        error: errorMessage
      });
      return {
        success: false,
        error: `Direct API call exception: ${errorMessage}`
      };
    }
  }
  /**
   * Вызов конкретного endpoint
   */
  async callEndpoint(endpoint, request) {
    const { prompt, model = "gemini-2.5-flash-image-preview", sourceImages = [] } = request;
    this.logger ? {
      info: this.logger.info.bind(this.logger),
      error: this.logger.error.bind(this.logger),
      debug: this.logger.debug.bind(this.logger),
      warn: this.logger.info.bind(this.logger)} : void 0;
    const resolvedImageUrls = await resolveImageUrls(sourceImages, this.logger);
    const updatedRequest = { sourceImages: resolvedImageUrls };
    if (endpoint.method === "generateContent") {
      const parts = [];
      if (updatedRequest.sourceImages && updatedRequest.sourceImages.length > 0) {
        this.logger?.info("\u{1F5BC}\uFE0F [HubaiGemini] Processing multiple source images", {
          totalImages: updatedRequest.sourceImages.length,
          maxImages: 4
        });
        let processedImages = 0;
        for (const imageUrl of updatedRequest.sourceImages.slice(0, 4)) {
          try {
            this.logger?.debug("\u{1F527} [HubaiGemini] Processing image", {
              imageUrl: imageUrl.substring(0, 50) + "...",
              imageIndex: processedImages + 1
            });
            const imageData = await this.fetchImageAsBase64(imageUrl);
            if (imageData) {
              parts.push({
                inlineData: {
                  data: imageData.base64,
                  mimeType: imageData.mimeType
                }
              });
              processedImages++;
              this.logger?.info("\u2705 [HubaiGemini] Image processed successfully", {
                imageIndex: processedImages,
                mimeType: imageData.mimeType,
                sizeKB: Math.round(imageData.base64.length / 1024)
              });
            } else {
              this.logger?.error("\u274C [HubaiGemini] Failed to convert image to base64", {
                imageUrl: imageUrl.substring(0, 50) + "..."
              });
            }
          } catch (error) {
            this.logger?.error("\u274C [HubaiGemini] Error processing source image", {
              imageUrl: imageUrl.substring(0, 50) + "...",
              error: error instanceof Error ? error.message : String(error)
            });
          }
        }
        this.logger?.info("\u{1F4CA} [HubaiGemini] Image processing complete", {
          requestedImages: updatedRequest.sourceImages.length,
          processedImages,
          totalParts: parts.length - 1
          // -1 потому что текст еще не добавлен
        });
      }
      const imagePrompt = `Create a high-quality image: ${prompt}

Generate a detailed, professional-quality image that accurately represents the description. 
${updatedRequest.sourceImages.length > 0 ? "Use the provided reference images for inspiration and context." : ""}

Requirements:
- High resolution and detailed
- Visually appealing and professional
- Accurate representation of the description
- Creative and artistic quality

Please generate the image now.`;
      parts.push({ text: imagePrompt });
      const response = await fetch(endpoint.url, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${this.apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          contents: [{
            parts
          }],
          generationConfig: {
            temperature: 0.8,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 4096
          },
          safetySettings: [
            { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
            { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
            { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
            { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_MEDIUM_AND_ABOVE" }
          ]
        })
      });
      if (response.ok) {
        const result = await response.json();
        this.logger?.info("\u{1F4E5} [HubaiGemini] API response received", {
          hasResult: !!result,
          hasCandidates: !!(result.candidates && result.candidates.length > 0),
          candidatesCount: result.candidates ? result.candidates.length : 0,
          responseSize: JSON.stringify(result).length
        });
        this.logger?.info("\u{1F50D} [HubaiGemini] DETAILED API RESPONSE STRUCTURE", {
          resultKeys: Object.keys(result || {}),
          fullResult: JSON.stringify(result, null, 2).substring(0, 2e3)
        });
        if (result.candidates && result.candidates[0]) {
          const candidate = result.candidates[0];
          this.logger?.info("\u{1F50D} [HubaiGemini] DETAILED CANDIDATE STRUCTURE", {
            candidateKeys: Object.keys(candidate || {}),
            hasContent: !!candidate.content,
            contentKeys: candidate.content ? Object.keys(candidate.content) : [],
            hasParts: candidate.content && candidate.content.parts,
            partsCount: candidate.content && candidate.content.parts ? candidate.content.parts.length : 0
          });
          if (candidate.content && candidate.content.parts) {
            candidate.content.parts.forEach((part, index) => {
              this.logger?.info(`\u{1F50D} [HubaiGemini] PART ${index} STRUCTURE`, {
                partKeys: Object.keys(part || {}),
                hasInlineData: !!part.inlineData,
                hasText: !!part.text,
                textLength: part.text ? part.text.length : 0,
                textPreview: part.text ? part.text.substring(0, 200) + "..." : null
              });
            });
          }
        }
        return this.processGenerateContentResponse(result, model, prompt);
      } else {
        const errorText = await response.text();
        this.logger?.error("\u274C [HubaiGemini] API request failed", {
          status: response.status,
          statusText: response.statusText,
          errorText: errorText.substring(0, 500) + (errorText.length > 500 ? "..." : "")
        });
        throw new Error(`GenerateContent API failed: ${response.status} - ${errorText}`);
      }
    } else if (endpoint.method === "chatCompletions") {
      const content = [];
      if (updatedRequest.sourceImages && updatedRequest.sourceImages.length > 0) {
        for (const imageUrl of updatedRequest.sourceImages.slice(0, 4)) {
          try {
            const imageData = await this.fetchImageAsBase64(imageUrl);
            if (imageData) {
              content.push({
                type: "image_url",
                image_url: {
                  url: `data:${imageData.mimeType};base64,${imageData.base64}`
                }
              });
            }
          } catch (error) {
            this.logger?.debug("\u26A0\uFE0F [HubaiGemini] Failed to process source image", { imageUrl });
          }
        }
      }
      const chatPrompt = `GENERATE_IMAGE_NOW: ${prompt}

You are an advanced AI image generator. Create a high-quality, detailed image based on the given description. 
${updatedRequest.sourceImages.length > 0 ? "Use any provided reference images as inspiration or context." : ""}

CRITICAL: You must actually generate and return a real image, not a text description. 
Return the image as base64-encoded data.

Style: Professional, detailed, high-resolution, visually appealing
Format: Return only the base64 image data

Generate the image now: ${prompt}`;
      content.push({
        type: "text",
        text: chatPrompt
      });
      const response = await fetch(endpoint.url, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${this.apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model,
          messages: [{ role: "user", content }],
          max_tokens: 4096,
          temperature: 0.8
        })
      });
      if (response.ok) {
        const result = await response.json();
        return this.processChatCompletionsResponse(result, model, prompt);
      } else {
        const errorText = await response.text();
        throw new Error(`Chat completions API failed: ${response.status} - ${errorText}`);
      }
    }
    throw new Error(`Unknown endpoint method: ${endpoint.method}`);
  }
  /**
   * Обработка ответа от generateContent API
   */
  processGenerateContentResponse(result, model, prompt) {
    this.logger?.info("\u{1F4DD} [HubaiGemini] Processing generateContent response", {
      hasCandidates: !!(result.candidates && result.candidates.length > 0),
      candidatesCount: result.candidates ? result.candidates.length : 0,
      model,
      promptLength: prompt.length
    });
    try {
      if (result.candidates && result.candidates[0]) {
        const candidate = result.candidates[0];
        this.logger?.debug("\u{1F50D} [HubaiGemini] Examining first candidate", {
          hasContent: !!candidate.content,
          hasParts: !!(candidate.content && candidate.content.parts),
          partsCount: candidate.content && candidate.content.parts ? candidate.content.parts.length : 0
        });
        if (candidate.content && candidate.content.parts) {
          for (const part of candidate.content.parts) {
            if (part.inlineData && part.inlineData.data) {
              this.logger?.info("\u2705 [HubaiGemini] Found image in generateContent response");
              return {
                success: true,
                imageBase64: part.inlineData.data,
                description: `Image generated using generateContent API with ${model} for: ${prompt.substring(0, 100)}${prompt.length > 100 ? "..." : ""}`
              };
            }
            if (part.text) {
              const imageBase64 = this.extractBase64FromText(part.text);
              if (imageBase64) {
                this.logger?.info("\u2705 [HubaiGemini] Found image in text part of generateContent response");
                return {
                  success: true,
                  imageBase64,
                  description: `Image extracted from text using generateContent API with ${model}`
                };
              }
            }
          }
        }
      }
      return {
        success: false,
        error: "No valid image data found in generateContent response"
      };
    } catch (error) {
      return {
        success: false,
        error: `Error processing generateContent response: ${error instanceof Error ? error.message : String(error)}`
      };
    }
  }
  /**
   * Обработка ответа от chat completions API
   */
  processChatCompletionsResponse(result, model, prompt) {
    this.logger?.debug("\u{1F4DD} [HubaiGemini] Processing chat completions response");
    try {
      const responseText = result.choices?.[0]?.message?.content || "";
      this.logger?.debug("\u{1F4DD} [HubaiGemini] Chat completions response length", {
        responseLength: responseText.length
      });
      const imageBase64 = this.extractBase64FromText(responseText);
      if (imageBase64) {
        this.logger?.info("\u2705 [HubaiGemini] Found image in chat completions response");
        return {
          success: true,
          imageBase64,
          description: `Image generated using chat completions API with ${model} for: ${prompt.substring(0, 100)}${prompt.length > 100 ? "..." : ""}`
        };
      } else {
        return {
          success: false,
          error: "No valid image data found in chat completions response"
        };
      }
    } catch (error) {
      return {
        success: false,
        error: `Error processing chat completions response: ${error instanceof Error ? error.message : String(error)}`
      };
    }
  }
  /**
   * Получение изображения как base64 данные
   */
  async fetchImageAsBase64(imageUrl) {
    try {
      this.logger?.debug("\u{1F527} [HubaiGemini] Fetching image", { imageUrl });
      const response = await fetch(imageUrl);
      if (!response.ok) {
        this.logger?.error("\u274C [HubaiGemini] Failed to fetch image", {
          imageUrl,
          status: response.status
        });
        return null;
      }
      const imageBuffer = await response.arrayBuffer();
      const base64 = Buffer.from(imageBuffer).toString("base64");
      const mimeType = response.headers.get("content-type") || "image/jpeg";
      this.logger?.debug("\u2705 [HubaiGemini] Image fetched successfully", {
        mimeType,
        size: base64.length
      });
      return { base64, mimeType };
    } catch (error) {
      this.logger?.error("\u274C [HubaiGemini] Error fetching image", {
        imageUrl,
        error: error instanceof Error ? error.message : String(error)
      });
      return null;
    }
  }
}
async function generateImageWithHubaiGemini(request, logger) {
  const generator = new HubaiGeminiGenerator(logger);
  return await generator.generateImage(request);
}

const DAILY_LIMIT_PRIVATE = 3;
const DAILY_LIMIT_GROUP = 30;
const ADMIN_USER_ID = "6913446846";
let dbPool = null;
function getDbPool() {
  if (!dbPool) {
    dbPool = new Pool({
      connectionString: process.env.DATABASE_URL,
      max: 10,
      // максимум соединений
      idleTimeoutMillis: 3e4,
      connectionTimeoutMillis: 2e3
    });
  }
  return dbPool;
}
async function reserveGenerationSlot(userId, username, chatType = "private") {
  const pool = getDbPool();
  const client = await pool.connect();
  try {
    console.log("\u{1F3AF} [UserLimits] Reserving generation slot for user", { userId, username });
    const isAdmin = userId === ADMIN_USER_ID;
    if (isAdmin) {
      console.log("\u{1F451} [UserLimits] Admin user detected - unlimited access", { userId });
      return {
        canGenerate: true,
        dailyCount: 0,
        remaining: 999,
        isAdmin: true,
        limitReached: false,
        message: "\u0410\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440 - \u0431\u0435\u0437\u043B\u0438\u043C\u0438\u0442\u043D\u044B\u0439 \u0434\u043E\u0441\u0442\u0443\u043F"
      };
    }
    const dailyLimit = chatType === "private" ? DAILY_LIMIT_PRIVATE : DAILY_LIMIT_GROUP;
    console.log("\u{1F4CA} [UserLimits] Using daily limit", { userId, chatType, dailyLimit });
    await client.query(`
      INSERT INTO users (user_id, username, daily_image_count, last_reset_date)
      VALUES ($1, $2, 0, CURRENT_DATE)
      ON CONFLICT (user_id) DO UPDATE SET
        username = EXCLUDED.username,
        daily_image_count = CASE 
          WHEN users.last_reset_date < CURRENT_DATE THEN 0
          ELSE users.daily_image_count
        END,
        last_reset_date = CASE 
          WHEN users.last_reset_date < CURRENT_DATE THEN CURRENT_DATE
          ELSE users.last_reset_date
        END;
    `, [userId, username]);
    const result = await client.query(`
      UPDATE users 
      SET daily_image_count = daily_image_count + 1
      WHERE user_id = $1 
        AND daily_image_count < $2
      RETURNING daily_image_count as final_count;
    `, [userId, dailyLimit]);
    const queryResult = result.rows[0];
    const slotReserved = queryResult ? true : false;
    const finalCount = queryResult ? queryResult.final_count : dailyLimit;
    if (!slotReserved) {
      console.log("\u274C [UserLimits] Failed to reserve slot - limit reached", {
        userId,
        finalCount,
        limit: dailyLimit
      });
      return {
        canGenerate: false,
        dailyCount: finalCount,
        remaining: 0,
        isAdmin: false,
        limitReached: true,
        message: chatType === "private" ? `\u{1F3AF} *\u0422\u0435\u0441\u0442\u043E\u0432\u044B\u0439 \u043F\u0435\u0440\u0438\u043E\u0434 \u0437\u0430\u043A\u043E\u043D\u0447\u0435\u043D!* \u0412\u044B \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043B\u0438 ${dailyLimit} \u0431\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u044B\u0445 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438.

\u{1F4B3} *\u0414\u043B\u044F \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u0431\u0435\u0437\u043B\u0438\u043C\u0438\u0442\u043D\u044B\u0445 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0439:*
\u2022 \u041E\u043F\u043B\u0430\u0442\u0438\u0442\u0435 \u043F\u043E \u0421\u0411\u041F: *89935801642* (\u0410\u043B\u044C\u0444\u0430 \u0411\u0430\u043D\u043A, \u0414\u043C\u0438\u0442\u0440\u0438\u0439)
\u2022 \u041E\u0442\u043F\u0440\u0430\u0432\u044C\u0442\u0435 \u0441\u043A\u0440\u0438\u043D\u0448\u043E\u0442 \u043F\u043B\u0430\u0442\u0435\u0436\u043A\u0438 @dmitriy_ferixdi

\u{1F381} *\u0423\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u0438 \u043E\u0431\u0449\u0435\u0439 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0438 \u043F\u043E\u043B\u0443\u0447\u0430\u044E\u0442 \u0434\u043E\u0441\u0442\u0443\u043F \u0431\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u043E \u0438 \u0431\u0435\u0437\u043B\u0438\u043C\u0438\u0442\u043D\u043E!*

\u2728 \u041F\u043E\u0441\u043B\u0435 \u043E\u043F\u043B\u0430\u0442\u044B \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u0435 \u043D\u0435\u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u043D\u044B\u0439 \u0434\u043E\u0441\u0442\u0443\u043F!` : `\u{1F4B0} *\u041B\u0438\u043C\u0438\u0442 \u0433\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0433\u043E \u0447\u0430\u0442\u0430 \u0438\u0441\u0447\u0435\u0440\u043F\u0430\u043D!* \u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u043E ${dailyLimit} \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0439.

\u{1F504} \u041B\u0438\u043C\u0438\u0442 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0441\u044F \u0437\u0430\u0432\u0442\u0440\u0430 \u0432 00:00 \u041C\u0421\u041A.

\u{1F4AC} \u041B\u0438\u0447\u043D\u044B\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F: ${DAILY_LIMIT_PRIVATE} \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0439/\u0434\u0435\u043D\u044C`
      };
    }
    const remaining = Math.max(0, dailyLimit - finalCount);
    console.log("\u2705 [UserLimits] Slot reserved successfully", {
      userId,
      finalCount,
      remaining,
      limit: dailyLimit
    });
    return {
      canGenerate: true,
      dailyCount: finalCount,
      remaining,
      isAdmin: false,
      limitReached: false,
      message: remaining > 0 ? `\u0421\u043B\u043E\u0442 \u0437\u0430\u0440\u0435\u0437\u0435\u0440\u0432\u0438\u0440\u043E\u0432\u0430\u043D! \u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C ${remaining} \u0438\u0437 ${dailyLimit} \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432 \u043D\u0430 \u0441\u0435\u0433\u043E\u0434\u043D\u044F.` : `\u0421\u043B\u043E\u0442 \u0437\u0430\u0440\u0435\u0437\u0435\u0440\u0432\u0438\u0440\u043E\u0432\u0430\u043D! \u042D\u0442\u043E \u0432\u0430\u0448 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u0437\u0430\u043F\u0440\u043E\u0441 \u043D\u0430 \u0441\u0435\u0433\u043E\u0434\u043D\u044F.`
    };
  } catch (error) {
    console.error("\u274C [UserLimits] Database error:", error);
    return {
      canGenerate: false,
      dailyCount: 0,
      remaining: 0,
      isAdmin: false,
      limitReached: true,
      message: "\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u0440\u0435\u0437\u0435\u0440\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0441\u043B\u043E\u0442\u0430. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u043F\u043E\u0437\u0436\u0435."
    };
  } finally {
    client.release();
  }
}
async function releaseReservedSlot(userId) {
  const pool = getDbPool();
  const client = await pool.connect();
  try {
    console.log("\u21A9\uFE0F [UserLimits] Releasing reserved slot due to generation failure", { userId });
    const isAdmin = userId === ADMIN_USER_ID;
    if (isAdmin) {
      return;
    }
    const result = await client.query(`
      UPDATE users 
      SET daily_image_count = GREATEST(daily_image_count - 1, 0)
      WHERE user_id = $1 
        AND last_reset_date = CURRENT_DATE 
        AND daily_image_count > 0
      RETURNING daily_image_count;
    `, [userId]);
    if (result.rows.length > 0) {
      console.log("\u2705 [UserLimits] Reserved slot released", {
        userId,
        newCount: result.rows[0].daily_image_count
      });
    } else {
      console.log("\u26A0\uFE0F [UserLimits] Could not release slot - user not found or count already 0", { userId });
    }
  } catch (error) {
    console.error("\u274C [UserLimits] Error releasing reserved slot:", error);
  } finally {
    client.release();
  }
}
async function getUserStats(userId, chatType = "private") {
  const pool = getDbPool();
  const client = await pool.connect();
  try {
    const isAdmin = userId === ADMIN_USER_ID;
    if (isAdmin) {
      return {
        canGenerate: true,
        dailyCount: 0,
        remaining: 999,
        isAdmin: true,
        limitReached: false,
        message: "\u0410\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440 - \u0431\u0435\u0437\u043B\u0438\u043C\u0438\u0442\u043D\u044B\u0439 \u0434\u043E\u0441\u0442\u0443\u043F"
      };
    }
    const result = await client.query(`
      SELECT user_id, username, 
        CASE 
          WHEN last_reset_date < CURRENT_DATE THEN 0
          ELSE daily_image_count
        END as current_count
      FROM users 
      WHERE user_id = $1;
    `, [userId]);
    if (result.rows.length === 0) {
      return null;
    }
    const dailyLimit = chatType === "private" ? DAILY_LIMIT_PRIVATE : DAILY_LIMIT_GROUP;
    const currentCount = result.rows[0].current_count;
    const remaining = Math.max(0, dailyLimit - currentCount);
    const limitReached = currentCount >= dailyLimit;
    return {
      canGenerate: !limitReached,
      dailyCount: currentCount,
      remaining,
      isAdmin: false,
      limitReached,
      message: limitReached ? `\u041F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u0434\u043D\u0435\u0432\u043D\u043E\u0439 \u043B\u0438\u043C\u0438\u0442! \u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u043E ${currentCount}/${dailyLimit} \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432.` : `\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u043E ${currentCount}/${dailyLimit} \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432. \u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C: ${remaining}`
    };
  } catch (error) {
    console.error("\u274C [UserLimits] Error getting user stats:", error);
    return null;
  } finally {
    client.release();
  }
}

const step1 = createStep({
  id: "process-message",
  description: "Process user message and generate image using Gemini 2.5 Flash Image Preview",
  inputSchema: z.object({
    message: z.string().describe("The message text from the user"),
    fileIds: z.array(z.string()).optional().describe("Array of Telegram file_id if any"),
    chatId: z.string().describe("Telegram chat ID"),
    userId: z.string().describe("Telegram user ID for rate limiting"),
    userName: z.string().optional().describe("Username of the sender"),
    messageId: z.string().optional().describe("Message ID for reply reference"),
    threadId: z.string().describe("Thread ID for conversation context"),
    chatType: z.string().optional().default("private").describe("Chat type: private, group, supergroup, channel")
  }),
  outputSchema: z.object({
    response: z.string().describe("The response message"),
    imagePath: z.string().nullable().optional().describe("Path to generated image file"),
    chatId: z.string().describe("Chat ID to send response to"),
    messageId: z.string().optional().describe("Original message ID for reply"),
    success: z.boolean().describe("Whether generation was successful"),
    imageSent: z.boolean().optional().describe("Whether image was already sent directly from step1"),
    userId: z.string().describe("User ID for limit tracking")
    // Note: Removed showModeButtons - no longer needed without mode selection
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [Step1] Processing message for Gemini 2.5 Flash Image Preview", {
      messageLength: inputData.message.length,
      imageCount: inputData.fileIds?.length || 0,
      chatId: inputData.chatId,
      userId: inputData.userId
    });
    let slotReservation;
    try {
      if (inputData.message === "/start") {
        logger?.info("\u{1F527} [Step1] Sending greeting message");
        return {
          response: "\u041F\u0440\u0438\u0432\u0435\u0442. \u042D\u0442\u043E \u0440\u0435\u0436\u0438\u043C \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 Nano Banano. \u0421\u043A\u0430\u0436\u0438 \u0447\u0451 \u043D\u0430\u0434\u043E, \u0441\u0433\u0435\u043D\u0435\u0440\u0438\u0440\u0443\u044E.",
          chatId: inputData.chatId,
          messageId: inputData.messageId,
          success: true,
          imageSent: false,
          userId: inputData.userId
        };
      }
      if (inputData.fileIds && inputData.fileIds.length > 0 && (!inputData.message || inputData.message.trim().length === 0)) {
        logger?.info("\u{1F5BC}\uFE0F [Step1] Photos without text detected", {
          photoCount: inputData.fileIds.length,
          messageLength: inputData.message?.length || 0
        });
        const photoCount = inputData.fileIds.length;
        const responseText = photoCount === 1 ? "\u0427\u0442\u043E \u0445\u043E\u0447\u0435\u0448\u044C \u0441\u0434\u0435\u043B\u0430\u0442\u044C \u0441 \u044D\u0442\u043E\u0439 \u0444\u043E\u0442\u043A\u043E\u0439?" : "\u0427\u0442\u043E \u0445\u043E\u0447\u0435\u0448\u044C \u0441\u0434\u0435\u043B\u0430\u0442\u044C \u0441 \u044D\u0442\u0438\u043C\u0438 \u0444\u043E\u0442\u043A\u0430\u043C\u0438?";
        return {
          response: responseText,
          chatId: inputData.chatId,
          messageId: inputData.messageId,
          success: true,
          imageSent: false,
          userId: inputData.userId
        };
      }
      logger?.info("\u{1F3AF} [Step1] Reserving generation slot", {
        userId: inputData.userId,
        userName: inputData.userName
      });
      slotReservation = await reserveGenerationSlot(
        inputData.userId,
        inputData.userName || "Unknown",
        inputData.chatType || "private"
      );
      if (!slotReservation.canGenerate) {
        logger?.info("\u274C [Step1] Failed to reserve slot - limit exceeded", {
          userId: inputData.userId,
          dailyCount: slotReservation.dailyCount,
          limitReached: slotReservation.limitReached,
          chatType: inputData.chatType
        });
        const isGroupChat = inputData.chatType === "group" || inputData.chatType === "supergroup";
        const limitMessage = isGroupChat ? "\u{1F6AB} \u041B\u0438\u043C\u0438\u0442 \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432 \u0434\u043B\u044F \u0447\u0430\u0442\u0430 \u043F\u043E \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0439 Nano Banano \u0437\u0430\u043A\u043E\u043D\u0447\u0438\u043B\u0441\u044F (30/30). \u041B\u0438\u043C\u0438\u0442\u044B \u043E\u0431\u043D\u043E\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u043A\u0430\u0436\u0434\u044B\u0435 \u0441\u0443\u0442\u043A\u0438 \u0432 00:00 \u041C\u0421\u041A." : "\u0412\u0430\u0448 \u043B\u0438\u043C\u0438\u0442 \u043D\u0430 \u0441\u0435\u0433\u043E\u0434\u043D\u044F \u0437\u0430\u043A\u043E\u043D\u0447\u0435\u043D: 3/3. \u041F\u0440\u0438\u0445\u043E\u0434\u0438\u0442\u0435 \u0437\u0430\u0432\u0442\u0440\u0430. \u0425\u043E\u0447\u0435\u0448\u044C \u0431\u0435\u0437\u043B\u0438\u043C\u0438\u0442? \u041F\u0438\u0448\u0438 @dmitriy_ferixdi";
        return {
          response: limitMessage,
          chatId: inputData.chatId,
          messageId: inputData.messageId,
          success: false,
          userId: inputData.userId
        };
      }
      logger?.info("\u2705 [Step1] Generation slot reserved", {
        userId: inputData.userId,
        dailyCount: slotReservation.dailyCount,
        remaining: slotReservation.remaining,
        isAdmin: slotReservation.isAdmin
      });
      logger?.info("\u{1F527} [Step1] Calling Hubai Gemini generator with Google SDK", {
        prompt: inputData.message.substring(0, 50) + "...",
        hasImages: !!(inputData.fileIds && inputData.fileIds.length > 0)
      });
      let result;
      try {
        logger?.info("\u{1F527} [Step1] About to call generateImageWithHubaiGemini", {
          prompt: inputData.message.substring(0, 50) + "...",
          imageCount: inputData.fileIds?.length || 0,
          fileIds: inputData.fileIds ? inputData.fileIds.map((f) => f.substring(0, 15) + "...") : []
        });
        result = await generateImageWithHubaiGemini({
          prompt: inputData.message,
          model: "gemini-2.5-flash-image-preview",
          // Nano Banana модель
          sourceImages: inputData.fileIds
        }, logger);
      } catch (error) {
        logger?.error("\u274C [Step1] Exception in generateImageWithHubaiGemini", {
          error: error instanceof Error ? error.message : String(error),
          stack: error instanceof Error ? error.stack : void 0
        });
        result = {
          success: false,
          error: `Exception in generateImageWithHubaiGemini: ${error instanceof Error ? error.message : String(error)}`
        };
      }
      logger?.info("\u2705 [Step1] Generation completed", {
        success: result.success,
        hasImage: !!result.imageBase64,
        description: result.description
      });
      if (!result.success && !slotReservation.isAdmin) {
        logger?.info("\u21A9\uFE0F [Step1] Releasing reserved slot due to generation failure");
        await releaseReservedSlot(inputData.userId);
      }
      if (result.success && result.imageBase64) {
        logger?.info("\u2705 [Step1] Image generated successfully, saving to temporary file");
        try {
          const crypto = require$$0;
          const fs = require$$1;
          const path = require$$2;
          const imageId = crypto.randomUUID();
          const tempFilePath = path.join("/tmp", `nano_banana_${imageId}.jpg`);
          const imageBuffer = Buffer.from(result.imageBase64, "base64");
          fs.writeFileSync(tempFilePath, imageBuffer);
          logger?.info("\u2705 [Step1] Image saved to temporary file", {
            tempFilePath,
            imageSize: imageBuffer.length,
            chatId: inputData.chatId
          });
          return {
            response: result.description || "\u{1F34C} \u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0433\u043E\u0442\u043E\u0432\u043E!",
            imagePath: tempFilePath,
            // Передаем путь к файлу вместо base64!
            chatId: inputData.chatId,
            messageId: inputData.messageId,
            success: true,
            imageSent: false,
            // Step2 будет отправлять
            userId: inputData.userId
          };
        } catch (fileError) {
          logger?.error("\u274C [Step1] Failed to save image to temp file", {
            error: fileError instanceof Error ? fileError.message : String(fileError),
            chatId: inputData.chatId
          });
          logger?.warn("\u26A0\uFE0F [Step1] Falling back to base64 transfer (may cause output_too_large)");
          return {
            response: result.description || "\u{1F34C} \u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0433\u043E\u0442\u043E\u0432\u043E!",
            imagePath: result.imageBase64,
            // Возвращаем base64 как fallback
            chatId: inputData.chatId,
            messageId: inputData.messageId,
            success: true,
            imageSent: false,
            userId: inputData.userId
          };
        }
      }
      let responseMessage = "";
      if (!result.success) {
        const currentRemaining = slotReservation.isAdmin ? 999 : Math.min(slotReservation.remaining + 1, 5);
        const limitInfo = slotReservation.isAdmin ? "" : `

\u{1F4CA} \u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u043F\u044B\u0442\u043E\u043A \u0441\u0435\u0433\u043E\u0434\u043D\u044F: ${currentRemaining}/5`;
        responseMessage = (result.error || "\u274C Nano Banana \u043D\u0435 \u0441\u043C\u043E\u0433 \u0441\u0433\u0435\u043D\u0435\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0434\u0440\u0443\u0433\u043E\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435!") + limitInfo;
      } else {
        responseMessage = "\u274C \u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u043D\u0435 \u0431\u044B\u043B\u043E \u0441\u0433\u0435\u043D\u0435\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043E.";
      }
      return {
        response: responseMessage,
        imagePath: null,
        // НЕ передаем base64!
        chatId: inputData.chatId,
        messageId: inputData.messageId,
        success: result.success,
        userId: inputData.userId
      };
    } catch (error) {
      logger?.error("\u274C [Step1] Error in generation processing", {
        error: error instanceof Error ? error.message : String(error),
        userId: inputData.userId
      });
      if (typeof slotReservation !== "undefined" && slotReservation?.canGenerate && !slotReservation?.isAdmin) {
        logger?.info("\u21A9\uFE0F [Step1] Releasing reserved slot due to unexpected error");
        try {
          await releaseReservedSlot(inputData.userId);
        } catch (releaseError) {
          logger?.error("\u274C [Step1] Failed to release reserved slot", {
            releaseError: releaseError instanceof Error ? releaseError.message : String(releaseError),
            userId: inputData.userId
          });
        }
      }
      return {
        response: "\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438, \u043E\u0431\u0440\u0430\u0442\u0438\u0442\u0435\u0441\u044C \u043A @dmitriy_ferixdi",
        chatId: inputData.chatId,
        messageId: inputData.messageId,
        success: false,
        imageSent: false,
        userId: inputData.userId
      };
    }
  }
});
const step2 = createStep({
  id: "send-telegram-response",
  description: "Send the response (with optional image) back to the Telegram chat",
  inputSchema: z.object({
    response: z.string().describe("The response message"),
    imagePath: z.string().nullable().optional().describe("Path to generated image file"),
    chatId: z.string().describe("Chat ID to send response to"),
    messageId: z.string().optional().describe("Original message ID for reply"),
    success: z.boolean().describe("Whether generation was successful"),
    imageSent: z.boolean().optional().describe("Whether image was already sent directly from step1"),
    userId: z.string().describe("User ID for limit tracking")
  }),
  outputSchema: z.object({
    success: z.boolean().describe("Whether the message was sent successfully"),
    sentMessageId: z.string().optional().describe("ID of the sent message")
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [Step2] Sending response to Telegram", {
      chatId: inputData.chatId,
      responseLength: inputData.response.length,
      hasImage: !!inputData.imagePath,
      imageSent: !!inputData.imageSent
    });
    try {
      if (!process.env.TELEGRAM_BOT_TOKEN) {
        throw new Error("TELEGRAM_BOT_TOKEN not found in environment variables");
      }
      const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
      if (inputData.imagePath) {
        logger?.info("\u{1F527} [Step2] Sending image response");
        let imageBuffer;
        if (inputData.imagePath.startsWith("/tmp/")) {
          const fs = require$$1;
          logger?.info("\u{1F4C1} [Step2] Reading image from temporary file", {
            filePath: inputData.imagePath
          });
          imageBuffer = fs.readFileSync(inputData.imagePath);
          try {
            fs.unlinkSync(inputData.imagePath);
            logger?.info("\u{1F5D1}\uFE0F [Step2] Temporary file deleted", {
              filePath: inputData.imagePath
            });
          } catch (deleteError) {
            logger?.warn("\u26A0\uFE0F [Step2] Failed to delete temporary file", {
              filePath: inputData.imagePath,
              error: deleteError instanceof Error ? deleteError.message : String(deleteError)
            });
          }
        } else {
          logger?.info("\u{1F4DD} [Step2] Converting base64 to buffer");
          imageBuffer = Buffer.from(inputData.imagePath, "base64");
        }
        const formData = new FormData();
        formData.append("chat_id", inputData.chatId);
        const uint8Array = new Uint8Array(imageBuffer);
        const blob = new Blob([uint8Array], { type: "image/jpeg" });
        formData.append("photo", blob, "generated_image.jpg");
        if (inputData.messageId) {
          formData.append("reply_parameters", JSON.stringify({
            message_id: parseInt(inputData.messageId)
          }));
        }
        const response = await fetch(`${telegramApiUrl}/sendPhoto`, {
          method: "POST",
          body: formData
        });
        const result = await response.json();
        if (!response.ok) {
          throw new Error(`Telegram API error: ${result.description || "Unknown error"}`);
        }
        logger?.info("\u2705 [Step2] Image sent to Telegram", {
          success: true,
          messageId: result.result?.message_id,
          chatId: inputData.chatId
        });
        try {
          logger?.info("\u{1F4C8} [Step2] Incrementing user image count after successful delivery", { userId: inputData.userId });
          await incrementUserImageCount(inputData.userId);
          logger?.info("\u2705 [Step2] User image count incremented successfully");
        } catch (countError) {
          logger?.error("\u274C [Step2] Failed to increment user count", {
            userId: inputData.userId,
            error: countError instanceof Error ? countError.message : String(countError)
          });
        }
        try {
          const adminChatId = "6913446846";
          if (inputData.chatId !== adminChatId) {
            logger?.info("\u{1F4E4} [Step2] Forwarding generation to admin chat");
            await fetch(`${telegramApiUrl}/forwardMessage`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                chat_id: adminChatId,
                from_chat_id: inputData.chatId,
                message_id: result.result?.message_id
              })
            });
            logger?.info("\u2705 [Step2] Generation forwarded to admin chat");
          }
        } catch (forwardError) {
          logger?.warn("\u26A0\uFE0F [Step2] Failed to forward to admin chat", {
            error: forwardError instanceof Error ? forwardError.message : String(forwardError)
          });
        }
        return {
          success: true,
          sentMessageId: result.result?.message_id?.toString()
        };
      } else {
        logger?.info("\u{1F527} [Step2] Sending text response");
        const payload = {
          chat_id: inputData.chatId,
          text: inputData.response,
          parse_mode: "HTML"
        };
        if (inputData.messageId) {
          payload.reply_parameters = {
            message_id: parseInt(inputData.messageId)
          };
        }
        const response = await fetch(`${telegramApiUrl}/sendMessage`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(payload)
        });
        const result = await response.json();
        if (!response.ok) {
          throw new Error(`Telegram API error: ${result.description || "Unknown error"}`);
        }
        logger?.info("\u2705 [Step2] Text message sent to Telegram", {
          success: true,
          messageId: result.result?.message_id,
          chatId: inputData.chatId
        });
        return {
          success: true,
          sentMessageId: result.result?.message_id?.toString()
        };
      }
    } catch (error) {
      logger?.error("\u274C [Step2] Error sending message", {
        error: error instanceof Error ? error.message : String(error),
        chatId: inputData.chatId
      });
      return {
        success: false,
        sentMessageId: void 0
      };
    }
  }
});
const telegramBotWorkflow = createWorkflow({
  id: "telegram-multimodal-bot",
  description: "Simple Telegram bot using Gemini 2.5 Flash Image Preview for image generation",
  inputSchema: z.object({
    message: z.string().describe("The message text from the user"),
    fileIds: z.array(z.string()).optional().describe("Array of Telegram file_id if any"),
    chatId: z.string().describe("Telegram chat ID"),
    userId: z.string().describe("Telegram user ID for rate limiting"),
    userName: z.string().optional().describe("Username of the sender"),
    messageId: z.string().optional().describe("Message ID for reply reference"),
    threadId: z.string().describe("Thread ID for conversation context"),
    chatType: z.string().optional().default("private").describe("Chat type: private, group, supergroup, channel")
  }),
  outputSchema: z.object({
    success: z.boolean().describe("Whether the message was sent successfully"),
    sentMessageId: z.string().optional().describe("ID of the sent message")
  })
}).then(step1).then(step2).commit();

const userStatsTool = createTool({
  id: "user-stats-tool",
  description: "Get comprehensive user statistics from database including daily image count, total generations, and last reset date. Shows user's usage patterns and history.",
  inputSchema: z.object({
    user_id: z.string().describe("Telegram user ID to get statistics for"),
    username: z.string().optional().describe("Username to update in database if provided")
  }),
  outputSchema: z.object({
    success: z.boolean().describe("Whether statistics were retrieved successfully"),
    daily_count: z.number().describe("Number of images generated today"),
    total_count: z.number().describe("Total number of images ever generated"),
    last_reset_date: z.string().describe("Date when daily counter was last reset (YYYY-MM-DD format)"),
    remaining_daily: z.number().describe("Remaining images available today (15 - daily_count, or 999999 for admins)"),
    recent_generations: z.array(z.object({
      id: z.number(),
      prompt: z.string(),
      created_at: z.string()
    })).describe("Last 5 image generations with details"),
    message: z.string().describe("Formatted statistics message for the user")
  }),
  execute: async ({ context: { user_id, username }, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [UserStatsTool] Getting user statistics", {
      user_id,
      username
    });
    try {
      logger?.info("\u{1F4DD} [UserStatsTool] Ensuring user exists in database");
      await upsertUser(user_id, username || `user_${user_id}`);
      logger?.info("\u{1F4DD} [UserStatsTool] Getting daily count");
      const dailyCount = await getUserDailyCount(user_id);
      logger?.info("\u{1F4DD} [UserStatsTool] Getting total count from database");
      const [totalResult] = await db.select({ count: count() }).from(image_generations).where(eq(image_generations.user_id, user_id));
      const totalCount = totalResult?.count || 0;
      logger?.info("\u{1F4DD} [UserStatsTool] Getting user data for reset date");
      const [user] = await db.select().from(users).where(eq(users.user_id, user_id));
      const lastResetDate = user?.last_reset_date || (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
      logger?.info("\u{1F4DD} [UserStatsTool] Getting recent generations");
      const recentGenerations = await getUserImageHistory(user_id, 5);
      const isAdmin = isAdminUser(user_id);
      const remainingDaily = isAdmin ? 999999 : Math.max(0, 15 - dailyCount);
      const dailyLimit = isAdmin ? "\u221E" : "15";
      const formattedGenerations = recentGenerations.map((gen) => ({
        id: gen.id,
        prompt: gen.prompt.length > 50 ? gen.prompt.substring(0, 50) + "..." : gen.prompt,
        created_at: gen.created_at.toISOString()
      }));
      const adminBadge = isAdmin ? "\u{1F451} *\u0410\u0414\u041C\u0418\u041D\u0418\u0421\u0422\u0420\u0410\u0422\u041E\u0420* \u{1F451}\n" : "";
      const limitDisplay = isAdmin ? "\u221E (\u0431\u0435\u0437\u043B\u0438\u043C\u0438\u0442\u043D\u043E)" : remainingDaily.toString();
      const message = `\u{1F4CA} *\u0412\u0430\u0448\u0430 \u0441\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0430:*
${adminBadge}
\u{1F538} *\u0417\u0430 \u0441\u0435\u0433\u043E\u0434\u043D\u044F:* ${dailyCount}/${dailyLimit} \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0439
\u{1F538} *\u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C \u0441\u0435\u0433\u043E\u0434\u043D\u044F:* ${limitDisplay} \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0439
\u{1F538} *\u0412\u0441\u0435\u0433\u043E \u0441\u0433\u0435\u043D\u0435\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043E:* ${totalCount} \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0439
\u{1F538} *\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u0441\u0431\u0440\u043E\u0441:* ${lastResetDate}

${recentGenerations.length > 0 ? `\u{1F3A8} *\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0435 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438:*
${recentGenerations.slice(0, 3).map(
        (gen, i) => `${i + 1}. ${gen.prompt.length > 40 ? gen.prompt.substring(0, 40) + "..." : gen.prompt}`
      ).join("\n")}` : ""}

\u{1F4A1} ${isAdmin ? "\u0412\u0430\u043C \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u0431\u0435\u0437\u043B\u0438\u043C\u0438\u0442\u043D\u0430\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044F!" : "\u041B\u0438\u043C\u0438\u0442 \u0441\u0431\u0440\u0430\u0441\u044B\u0432\u0430\u0435\u0442\u0441\u044F \u043A\u0430\u0436\u0434\u044B\u0439 \u0434\u0435\u043D\u044C \u0432 00:00 UTC"}`;
      logger?.info("\u2705 [UserStatsTool] Statistics retrieved successfully", {
        user_id,
        daily_count: dailyCount,
        total_count: totalCount,
        remaining_daily: remainingDaily,
        recent_count: recentGenerations.length
      });
      return {
        success: true,
        daily_count: dailyCount,
        total_count: totalCount,
        last_reset_date: lastResetDate,
        remaining_daily: remainingDaily,
        recent_generations: formattedGenerations,
        message
      };
    } catch (error) {
      logger?.error("\u274C [UserStatsTool] Error getting user statistics", {
        error: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : void 0,
        user_id
      });
      return {
        success: false,
        daily_count: 0,
        total_count: 0,
        last_reset_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
        remaining_daily: 50,
        recent_generations: [],
        message: "\u274C \u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u0441\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0443. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u043F\u043E\u0437\u0436\u0435."
      };
    }
  }
});

if (!process.env.TELEGRAM_BOT_TOKEN) {
  console.warn(
    "Trying to initialize Telegram triggers without TELEGRAM_BOT_TOKEN. Can you confirm that the Telegram integration is configured correctly?"
  );
}
function registerTelegramTrigger({
  triggerType,
  handler
}) {
  return [
    registerApiRoute("/webhooks/telegram/action", {
      method: "POST",
      handler: async (c) => {
        const mastra = c.get("mastra");
        const logger = mastra.getLogger();
        try {
          const payload = await c.req.json();
          logger?.info("\u{1F4DD} [Telegram] payload", payload);
          if (payload.callback_query) {
            logger?.info("\u{1F518} [Telegram] Processing callback query", {
              data: payload.callback_query.data,
              from: payload.callback_query.from.username
            });
            await handler(mastra, {
              type: "telegram/callback_query",
              params: {
                userName: payload.callback_query.from.username || "Unknown",
                callbackData: payload.callback_query.data,
                userId: payload.callback_query.from.id.toString(),
                messageId: payload.callback_query.message.message_id.toString(),
                chatId: payload.callback_query.message.chat.id.toString()
              },
              payload
            });
            return c.text("OK", 200);
          } else if (payload.message) {
            logger?.info("\u{1F4AC} [Telegram] Processing message", {
              text: payload.message.text,
              from: payload.message.from.username
            });
            await handler(mastra, {
              type: triggerType,
              params: {
                userName: payload.message.from.username,
                message: payload.message.text,
                userId: payload.message.from.id.toString()
                // Include Telegram user ID for rate limiting
              },
              payload
            });
            return c.text("OK", 200);
          } else {
            logger?.info("\u2139\uFE0F [Telegram] Ignoring unsupported event type", {
              eventTypes: Object.keys(payload)
            });
            return c.text("OK", 200);
          }
        } catch (error) {
          logger?.error("Error handling Telegram webhook:", error);
          return c.text("Internal Server Error", 500);
        }
      }
    })
  ];
}

const processedMessages = /* @__PURE__ */ new Set();
const MESSAGE_CACHE_SIZE = 1e3;
function addToProcessedMessages(messageId) {
  if (processedMessages.size >= MESSAGE_CACHE_SIZE) {
    const messagesToKeep = Array.from(processedMessages).slice(MESSAGE_CACHE_SIZE / 2);
    processedMessages.clear();
    messagesToKeep.forEach((id) => processedMessages.add(id));
  }
  processedMessages.add(messageId);
}
function isMessageProcessed(messageId) {
  return processedMessages.has(messageId);
}
class ProductionPinoLogger extends MastraLogger {
  logger;
  constructor(options = {}) {
    super(options);
    this.logger = pino({
      name: options.name || "app",
      level: options.level || LogLevel.INFO,
      base: {},
      formatters: {
        level: (label, _number) => ({
          level: label
        })
      },
      timestamp: () => `,"time":"${new Date(Date.now()).toISOString()}"`
    });
  }
  debug(message, args = {}) {
    this.logger.debug(args, message);
  }
  info(message, args = {}) {
    this.logger.info(args, message);
  }
  warn(message, args = {}) {
    this.logger.warn(args, message);
  }
  error(message, args = {}) {
    this.logger.error(args, message);
  }
}
const mastra = new Mastra({
  storage: sharedPostgresStorage,
  agents: {
    telegramBot
  },
  workflows: {
    telegramBotWorkflow
  },
  mcpServers: {
    allTools: new MCPServer({
      name: "allTools",
      version: "1.0.0",
      tools: {
        multimodalTool,
        geminiImageGenerationTool,
        subscriptionCheckTool,
        userStatsTool
      }
    })
  },
  bundler: {
    // A few dependencies are not properly picked up by
    // the bundler if they are not added directly to the
    // entrypoint.
    externals: ["@slack/web-api", "inngest", "inngest/hono", "hono", "hono/streaming"],
    // sourcemaps are good for debugging.
    sourcemap: true
  },
  server: {
    host: "0.0.0.0",
    port: 5e3,
    middleware: [async (c, next) => {
      const mastra2 = c.get("mastra");
      const logger = mastra2?.getLogger();
      logger?.debug("[Request]", {
        method: c.req.method,
        url: c.req.url
      });
      try {
        await next();
      } catch (error) {
        logger?.error("[Response]", {
          method: c.req.method,
          url: c.req.url,
          error
        });
        if (error instanceof MastraError) {
          if (error.id === "AGENT_MEMORY_MISSING_RESOURCE_ID") {
            throw new NonRetriableError(error.message, {
              cause: error
            });
          }
        } else if (error instanceof z.ZodError) {
          throw new NonRetriableError(error.message, {
            cause: error
          });
        }
        throw error;
      }
    }],
    apiRoutes: [
      // This API route is used to register the Mastra workflow (inngest function) on the inngest server
      {
        path: "/api/inngest",
        method: "ALL",
        createHandler: async ({
          mastra: mastra2
        }) => inngestServe({
          mastra: mastra2,
          inngest
        })
        // The inngestServe function integrates Mastra workflows with Inngest by:
        // 1. Creating Inngest functions for each workflow with unique IDs (workflow.${workflowId})
        // 2. Setting up event handlers that:
        //    - Generate unique run IDs for each workflow execution
        //    - Create an InngestExecutionEngine to manage step execution
        //    - Handle workflow state persistence and real-time updates
        // 3. Establishing a publish-subscribe system for real-time monitoring
        //    through the workflow:${workflowId}:${runId} channel
      },
      // Telegram webhook handler
      ...registerTelegramTrigger({
        triggerType: "telegram/message",
        handler: async (mastra2, triggerInfo) => {
          const logger = mastra2.getLogger();
          const payload = triggerInfo.payload;
          const message = payload?.message;
          if (payload?.callback_query) {
            const callbackQuery = payload.callback_query;
            const callbackData = callbackQuery.data;
            const userId2 = callbackQuery.from.id.toString();
            const userName2 = callbackQuery.from.username || "unknown";
            const chatId2 = callbackQuery.message?.chat?.id?.toString();
            logger?.info("\u{1F518} [Telegram Trigger] Processing callback query", {
              callbackData,
              userId: userId2,
              userName: userName2
            });
            if (callbackData === "get_referral_link") {
              try {
                await upsertUser(userId2, userName2);
                logger?.info("\u{1F517} [Referral Button] User upserted for referral", {
                  userId: userId2,
                  userName: userName2
                });
                const {
                  getOrCreateReferralCode
                } = await Promise.resolve().then(function () { return referralUtils; });
                const referralCode = await getOrCreateReferralCode(userId2, logger);
                if (!process.env.TELEGRAM_BOT_TOKEN) {
                  throw new Error("TELEGRAM_BOT_TOKEN not found in environment variables");
                }
                const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
                const botInfoResponse = await fetch(`${telegramApiUrl}/getMe`);
                const botInfo = await botInfoResponse.json();
                if (!botInfo.ok) {
                  throw new Error("Failed to get bot info");
                }
                const botUsername = botInfo.result.username;
                const referralLink = `https://t.me/${botUsername}?start=${referralCode}`;
                await fetch(`${telegramApiUrl}/answerCallbackQuery`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                    callback_query_id: callbackQuery.id,
                    text: "\u2705 \u041F\u043E\u043B\u0443\u0447\u0430\u0435\u043C \u0432\u0430\u0448\u0443 \u043F\u0430\u0440\u0442\u043D\u0435\u0440\u0441\u043A\u0443\u044E \u0441\u0441\u044B\u043B\u043A\u0443..."
                  })
                });
                await fetch(`${telegramApiUrl}/sendMessage`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                    chat_id: chatId2,
                    text: `\u{1F517} *\u0412\u0430\u0448\u0430 \u043F\u0430\u0440\u0442\u043D\u0435\u0440\u0441\u043A\u0430\u044F \u0441\u0441\u044B\u043B\u043A\u0430:*

${referralLink}

\u{1F4DD} *\u041A\u043E\u0434:* \`${referralCode}\`

\u{1F4B0} *\u0412\u0430\u0448\u0435 \u0432\u043E\u0437\u043D\u0430\u0433\u0440\u0430\u0436\u0434\u0435\u043D\u0438\u0435:* 25% \u043E\u0442 \u0432\u0441\u0435\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439 \u0440\u0435\u0444\u0435\u0440\u0430\u043B\u043E\u0432

\u{1F3AF} \u041F\u043E\u0434\u0435\u043B\u0438\u0442\u0435\u0441\u044C \u044D\u0442\u043E\u0439 \u0441\u0441\u044B\u043B\u043A\u043E\u0439 \u0441 \u0434\u0440\u0443\u0437\u044C\u044F\u043C\u0438, \u0447\u0442\u043E\u0431\u044B \u043E\u043D\u0438 \u043C\u043E\u0433\u043B\u0438 \u043F\u0440\u0438\u0441\u043E\u0435\u0434\u0438\u043D\u0438\u0442\u044C\u0441\u044F \u043A Nano Banana Bot!

\u{1F4B3} *\u0412\u044B\u043F\u043B\u0430\u0442\u044B:* \u0421\u0411\u041F 89935801642 (\u0410\u043B\u044C\u0444\u0430 \u0411\u0430\u043D\u043A, \u0414\u043C\u0438\u0442\u0440\u0438\u0439)`,
                    parse_mode: "Markdown"
                  })
                });
                logger?.info("\u{1F517} [Referral Button] Referral link sent successfully", {
                  userId: userId2,
                  userName: userName2,
                  referralCode
                });
              } catch (error) {
                logger?.error("\u274C [Referral Button] Error processing referral request", {
                  userId: userId2,
                  userName: userName2,
                  error: error instanceof Error ? error.message : String(error)
                });
                if (!process.env.TELEGRAM_BOT_TOKEN) return;
                const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
                await fetch(`${telegramApiUrl}/answerCallbackQuery`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                    callback_query_id: callbackQuery.id,
                    text: "\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u0441\u0441\u044B\u043B\u043A\u0438. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u043F\u043E\u0437\u0436\u0435.",
                    show_alert: true
                  })
                });
              }
            }
            if (callbackData === "generate_request") {
              try {
                if (!process.env.TELEGRAM_BOT_TOKEN) {
                  throw new Error("TELEGRAM_BOT_TOKEN not found in environment variables");
                }
                const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
                await fetch(`${telegramApiUrl}/answerCallbackQuery`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                    callback_query_id: callbackQuery.id,
                    text: "\u{1F3AF} \u0413\u043E\u0442\u043E\u0432 \u043A \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438!"
                  })
                });
                await fetch(`${telegramApiUrl}/sendMessage`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                    chat_id: chatId2,
                    text: "\u{1F3AF} \u0414\u0430, \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0439 \u0441\u0432\u043E\u0439 \u0437\u0430\u043F\u0440\u043E\u0441!",
                    parse_mode: "Markdown"
                  })
                });
                logger?.info("\u{1F3AF} [Generate Button] Generate request message sent successfully", {
                  userId: userId2,
                  userName: userName2
                });
              } catch (error) {
                logger?.error("\u274C [Generate Button] Error processing generate request", {
                  userId: userId2,
                  userName: userName2,
                  error: error instanceof Error ? error.message : String(error)
                });
                if (!process.env.TELEGRAM_BOT_TOKEN) return;
                const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
                await fetch(`${telegramApiUrl}/answerCallbackQuery`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                    callback_query_id: callbackQuery.id,
                    text: "\u274C \u041E\u0448\u0438\u0431\u043A\u0430. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u043F\u043E\u0437\u0436\u0435.",
                    show_alert: true
                  })
                });
              }
            }
            if (callbackData === "check_my_limit") {
              try {
                await upsertUser(userId2, userName2);
                logger?.info("\u{1F4CA} [Limit Button] User upserted for limit check", {
                  userId: userId2,
                  userName: userName2
                });
                const userStats = await getUserStats(userId2, "private");
                if (!process.env.TELEGRAM_BOT_TOKEN) {
                  throw new Error("TELEGRAM_BOT_TOKEN not found in environment variables");
                }
                const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
                await fetch(`${telegramApiUrl}/answerCallbackQuery`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                    callback_query_id: callbackQuery.id,
                    text: "\u{1F4CA} \u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C \u0432\u0430\u0448 \u043B\u0438\u043C\u0438\u0442..."
                  })
                });
                let limitText = "\u274C \u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E \u043E \u043B\u0438\u043C\u0438\u0442\u0430\u0445";
                if (userStats) {
                  if (userStats.isAdmin) {
                    limitText = "\u{1F451} \u0410\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440 - \u0431\u0435\u0437\u043B\u0438\u043C\u0438\u0442\u043D\u044B\u0439 \u0434\u043E\u0441\u0442\u0443\u043F";
                  } else {
                    const available = userStats.remaining;
                    const total = 3;
                    limitText = `\u{1F4CA} \u0412\u0430\u0448 \u043B\u0438\u043C\u0438\u0442: ${available}/${total} \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0439`;
                  }
                }
                await fetch(`${telegramApiUrl}/sendMessage`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                    chat_id: chatId2,
                    text: limitText,
                    parse_mode: "Markdown"
                  })
                });
                logger?.info("\u{1F4CA} [Limit Button] Limit info sent successfully", {
                  userId: userId2,
                  userName: userName2,
                  limitText
                });
              } catch (error) {
                logger?.error("\u274C [Limit Button] Error processing limit check", {
                  userId: userId2,
                  userName: userName2,
                  error: error instanceof Error ? error.message : String(error)
                });
                if (!process.env.TELEGRAM_BOT_TOKEN) return;
                const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
                await fetch(`${telegramApiUrl}/answerCallbackQuery`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                    callback_query_id: callbackQuery.id,
                    text: "\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u043B\u0438\u043C\u0438\u0442\u043E\u0432. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u043F\u043E\u0437\u0436\u0435.",
                    show_alert: true
                  })
                });
              }
            }
            if (callbackData === "buy_unlimited") {
              try {
                if (!process.env.TELEGRAM_BOT_TOKEN) {
                  throw new Error("TELEGRAM_BOT_TOKEN not found in environment variables");
                }
                const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
                await fetch(`${telegramApiUrl}/answerCallbackQuery`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                    callback_query_id: callbackQuery.id,
                    text: "\u{1F48E} \u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u043E \u0431\u0435\u0437\u043B\u0438\u043C\u0438\u0442\u0435..."
                  })
                });
                const paymentInfo = `\u{1F48E} *\u0411\u0435\u0437\u043B\u0438\u043C\u0438\u0442\u043D\u044B\u0439 \u0434\u043E\u0441\u0442\u0443\u043F*

\u{1F525} \u0413\u0435\u043D\u0435\u0440\u0438\u0440\u0443\u0439\u0442\u0435 \u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0443\u0433\u043E\u0434\u043D\u043E \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0439!

\u{1F4B0} *\u0414\u043B\u044F \u043E\u043F\u043B\u0430\u0442\u044B \u043F\u0435\u0440\u0435\u0432\u0435\u0434\u0438\u0442\u0435 \u043F\u043E \u0421\u0411\u041F 999\u20BD*
\u{1F4F1} \u041D\u043E\u043C\u0435\u0440: *89935801642*
\u{1F3E6} \u0410\u043B\u044C\u0444\u0430 \u0411\u0430\u043D\u043A \u0414\u043C\u0438\u0442\u0440\u0438\u0439

\u041F\u043E\u0441\u043B\u0435 \u043E\u043F\u043B\u0430\u0442\u044B \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E \u043D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 @dmitriy_ferixdi \u0441 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435\u043C \u043F\u043B\u0430\u0442\u0435\u0436\u0430`;
                await fetch(`${telegramApiUrl}/sendMessage`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                    chat_id: chatId2,
                    text: paymentInfo,
                    parse_mode: "Markdown"
                  })
                });
                logger?.info("\u{1F48E} [Buy Unlimited] Payment info sent successfully", {
                  userId: userId2,
                  userName: userName2
                });
              } catch (error) {
                logger?.error("\u274C [Buy Unlimited] Error processing buy unlimited request", {
                  userId: userId2,
                  userName: userName2,
                  error: error instanceof Error ? error.message : String(error)
                });
                if (!process.env.TELEGRAM_BOT_TOKEN) return;
                const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
                await fetch(`${telegramApiUrl}/answerCallbackQuery`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                    callback_query_id: callbackQuery.id,
                    text: "\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u043F\u043E\u0437\u0436\u0435.",
                    show_alert: true
                  })
                });
              }
            }
            return;
          }
          const safeMessageText = message?.text?.startsWith("/start ") ? "/start ***" : message?.text;
          logger?.info("\u{1F4DD} [Telegram Trigger] Received message", {
            type: triggerInfo.type,
            userId: triggerInfo.params.userId,
            userName: triggerInfo.params.userName,
            messageText: safeMessageText
          });
          if (!message) {
            logger?.warn("\u{1F4DD} [Telegram Trigger] No message in payload");
            return;
          }
          const messageKey = `${message.chat.id}_${message.message_id}`;
          if (isMessageProcessed(messageKey)) {
            logger?.info("\u{1F4DD} [Telegram Trigger] Message already processed, skipping", {
              messageId: message.message_id,
              chatId: message.chat.id
            });
            return;
          }
          addToProcessedMessages(messageKey);
          if (message.text?.startsWith("/start")) {
            logger?.info("\u{1F4DD} [Telegram Trigger] Handling /start command");
            const userId2 = message.from.id.toString();
            const userName2 = message.from.username || "unknown";
            const chatId2 = message.chat.id.toString();
            const startText = message.text.trim();
            const referralCode = startText.startsWith("/start ") ? startText.substring(7).trim() : null;
            logger?.info("\u{1F4DD} [Telegram Trigger] Start command details", {
              userId: userId2,
              userName: userName2,
              hasReferralCode: !!referralCode,
              referralCode: referralCode ? "***" : null
              // Don't log actual code for security
            });
            try {
              await upsertUser(userId2, userName2);
              logger?.info("\u{1F4DD} [Telegram Trigger] User upserted", {
                userId: userId2,
                userName: userName2
              });
              if (referralCode) {
                const {
                  processReferral,
                  notifyAdminAboutReferral
                } = await Promise.resolve().then(function () { return referralUtils; });
                const referralResult = await processReferral(userId2, referralCode, logger);
                if (referralResult.success && referralResult.referrerUserId) {
                  logger?.info("\u{1F389} [Referral] Referral processed successfully", {
                    referredUserId: userId2,
                    referrerUserId: referralResult.referrerUserId
                  });
                  await notifyAdminAboutReferral(referralResult.referrerUserId, userId2, logger);
                } else {
                  logger?.warn("\u{1F517} [Referral] Referral processing failed", {
                    referredUserId: userId2,
                    referralCode: "***"
                  });
                }
              }
              if (!process.env.TELEGRAM_BOT_TOKEN) {
                throw new Error("TELEGRAM_BOT_TOKEN not found in environment variables");
              }
              const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
              logger?.info("\u{1F4DD} [Telegram] Sending first message (welcome)");
              const response1 = await fetch(`${telegramApiUrl}/sendMessage`, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json"
                },
                body: JSON.stringify({
                  chat_id: chatId2,
                  text: "\u{1F3A8} *\u041F\u0440\u0438\u0432\u0435\u0442! \u0414\u043E\u0431\u0440\u043E \u043F\u043E\u0436\u0430\u043B\u043E\u0432\u0430\u0442\u044C \u0432 Nano Banana Bot!*\n\n\u042D\u0442\u043E \u043D\u0435\u0439\u0440\u043E\u0441\u0435\u0442\u044C \u0434\u043B\u044F \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u044F \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0439.",
                  parse_mode: "Markdown"
                })
              });
              const result1 = await response1.json();
              logger?.info("\u{1F4DD} [Telegram] First message response", {
                ok: response1.ok,
                status: response1.status,
                result: result1
              });
              await new Promise((resolve) => setTimeout(resolve, 500));
              logger?.info("\u{1F4DD} [Telegram] Sending second message (instructions)");
              const response2 = await fetch(`${telegramApiUrl}/sendMessage`, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json"
                },
                body: JSON.stringify({
                  chat_id: chatId2,
                  text: "\u{1F3AF} *\u041A\u0430\u043A \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u044C\u0441\u044F:*\n\n\u{1F4DD} \u041E\u043F\u0438\u0448\u0438\u0442\u0435 \u0447\u0442\u043E \u0445\u043E\u0442\u0438\u0442\u0435 - \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u0435 \u043A\u0430\u0440\u0442\u0438\u043D\u043A\u0443\n\u{1F5BC}\uFE0F \u041F\u0440\u0438\u0448\u043B\u0438\u0442\u0435 \u0444\u043E\u0442\u043E + \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439\n\n\u041F\u0440\u043E\u0441\u0442\u043E \u043D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 \u0438\u043B\u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u044C\u0442\u0435 \u0444\u043E\u0442\u043E!",
                  parse_mode: "Markdown"
                })
              });
              const result2 = await response2.json();
              logger?.info("\u{1F4DD} [Telegram] Second message response", {
                ok: response2.ok,
                status: response2.status,
                result: result2
              });
              await new Promise((resolve) => setTimeout(resolve, 500));
              const buttonPayload = {
                chat_id: chatId2,
                text: "\u{1F4B0} *\u0425\u043E\u0442\u0438\u0442\u0435 \u0437\u0430\u0440\u0430\u0431\u0430\u0442\u044B\u0432\u0430\u0442\u044C?*\n\n\u{1F389} \u041F\u0440\u0438\u0433\u043B\u0430\u0448\u0430\u0439\u0442\u0435 \u0434\u0440\u0443\u0437\u0435\u0439 \u0438 \u043F\u043E\u043B\u0443\u0447\u0430\u0439\u0442\u0435 *25% \u043E\u0442 \u0432\u0441\u0435\u0445 \u0438\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439*!",
                reply_markup: {
                  inline_keyboard: [[{
                    text: "\u{1F3AF} \u0413\u0435\u043D\u0435\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C",
                    callback_data: "generate_request"
                  }], [{
                    text: "\u{1F4CA} \u0423\u0437\u043D\u0430\u0442\u044C \u043C\u043E\u0439 \u043B\u0438\u043C\u0438\u0442",
                    callback_data: "check_my_limit"
                  }], [{
                    text: "\u{1F517} \u041F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043F\u0430\u0440\u0442\u043D\u0435\u0440\u0441\u043A\u0443\u044E \u0441\u0441\u044B\u043B\u043A\u0443",
                    callback_data: "get_referral_link"
                  }], [{
                    text: "\u{1F48E} \u041A\u0443\u043F\u0438\u0442\u044C \u0431\u0435\u0437\u043B\u0438\u043C\u0438\u0442",
                    callback_data: "buy_unlimited"
                  }]]
                },
                parse_mode: "Markdown"
              };
              logger?.info("\u{1F4DD} [Telegram] Sending third message with button", {
                payload: JSON.stringify(buttonPayload, null, 2)
              });
              const response3 = await fetch(`${telegramApiUrl}/sendMessage`, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json"
                },
                body: JSON.stringify(buttonPayload)
              });
              const result3 = await response3.json();
              logger?.info("\u{1F4DD} [Telegram] Third message (button) response", {
                ok: response3.ok,
                status: response3.status,
                result: result3
              });
              logger?.info("\u{1F4DD} [Telegram Trigger] Welcome greeting, instructions and referral info sent successfully");
            } catch (error) {
              logger?.error("\u{1F4DD} [Telegram Trigger] Error handling /start command", {
                error: error instanceof Error ? error.message : String(error)
              });
            }
            return;
          }
          if (message.text === "/referral") {
            logger?.info("\u{1F4DD} [Telegram Trigger] Handling /referral command");
            const userId2 = message.from.id.toString();
            const userName2 = message.from.username || "unknown";
            const chatId2 = message.chat.id.toString();
            try {
              await upsertUser(userId2, userName2);
              logger?.info("\u{1F517} [Referral] User upserted for referral", {
                userId: userId2,
                userName: userName2
              });
              const {
                getOrCreateReferralCode
              } = await Promise.resolve().then(function () { return referralUtils; });
              const referralCode = await getOrCreateReferralCode(userId2, logger);
              if (!process.env.TELEGRAM_BOT_TOKEN) {
                throw new Error("TELEGRAM_BOT_TOKEN not found in environment variables");
              }
              const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
              const botInfoResponse = await fetch(`${telegramApiUrl}/getMe`);
              const botInfo = await botInfoResponse.json();
              if (!botInfo.ok) {
                throw new Error("Failed to get bot info");
              }
              const botUsername = botInfo.result.username;
              const referralLink = `https://t.me/${botUsername}?start=${referralCode}`;
              await fetch(`${telegramApiUrl}/sendMessage`, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json"
                },
                body: JSON.stringify({
                  chat_id: chatId2,
                  text: `\u{1F517} *\u0412\u0430\u0448\u0430 \u0440\u0435\u0444\u0435\u0440\u0430\u043B\u044C\u043D\u0430\u044F \u0441\u0441\u044B\u043B\u043A\u0430:*

${referralLink}

\u{1F4DD} *\u041A\u043E\u0434:* \`${referralCode}\`

\u{1F4B0} *\u0412\u0430\u0448 \u0437\u0430\u0440\u0430\u0431\u043E\u0442\u043E\u043A:* 25% \u043E\u0442 \u0432\u0441\u0435\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439 \u0440\u0435\u0444\u0435\u0440\u0430\u043B\u043E\u0432

\u{1F3AF} \u041F\u043E\u0434\u0435\u043B\u0438\u0442\u0435\u0441\u044C \u044D\u0442\u043E\u0439 \u0441\u0441\u044B\u043B\u043A\u043E\u0439 \u0441 \u0434\u0440\u0443\u0437\u044C\u044F\u043C\u0438, \u0447\u0442\u043E\u0431\u044B \u043E\u043D\u0438 \u043C\u043E\u0433\u043B\u0438 \u043F\u0440\u0438\u0441\u043E\u0435\u0434\u0438\u043D\u0438\u0442\u044C\u0441\u044F \u043A Nano Banana Bot!

\u{1F4B3} \u0412\u044B\u043F\u043B\u0430\u0442\u044B: \u0421\u0411\u041F 89935801642 (\u0410\u043B\u044C\u0444\u0430 \u0411\u0430\u043D\u043A, \u0414\u043C\u0438\u0442\u0440\u0438\u0439)`,
                  parse_mode: "Markdown"
                })
              });
              logger?.info("\u{1F517} [Referral] Referral link sent successfully", {
                userId: userId2,
                userName: userName2,
                codeLength: referralCode.length
              });
            } catch (error) {
              logger?.error("\u{1F517} [Referral] Error handling /referral command", {
                userId: userId2,
                userName: userName2,
                error: error instanceof Error ? error.message : String(error)
              });
              if (process.env.TELEGRAM_BOT_TOKEN) {
                try {
                  const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
                  await fetch(`${telegramApiUrl}/sendMessage`, {
                    method: "POST",
                    headers: {
                      "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                      chat_id: chatId2,
                      text: "\u274C \u041F\u0440\u043E\u0438\u0437\u043E\u0448\u043B\u0430 \u043E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u0438 \u0440\u0435\u0444\u0435\u0440\u0430\u043B\u044C\u043D\u043E\u0439 \u0441\u0441\u044B\u043B\u043A\u0438. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u043F\u043E\u0437\u0436\u0435."
                    })
                  });
                } catch (sendError) {
                  logger?.error("\u{1F517} [Referral] Error sending error message", {
                    sendError
                  });
                }
              }
            }
            return;
          }
          const userId = message.from.id.toString();
          message.chat.id.toString();
          const userName = message.from.username || "unknown";
          logger?.info("\u{1F4CB} [Telegram Trigger] Processing message", {
            chatType: message.chat.type,
            chatId: message.chat.id,
            userId,
            userName
          });
          try {
            await upsertUser(userId, userName);
            logger?.info("\u{1F4DD} [Telegram Trigger] User upserted", {
              userId,
              userName
            });
          } catch (error) {
            logger?.error("\u274C [User upsert] Error upserting user", {
              error
            });
          }
          let messageText = message.caption || message.text || "";
          const generationKeywords = ["\u0433\u0435\u043D\u0435\u0440", "\u0441\u043E\u0437\u0434\u0430\u0439", "\u043D\u0430\u0440\u0438\u0441\u0443\u0439", "\u0441\u0434\u0435\u043B\u0430\u0439", "generate"];
          const hasGenerationRequest = generationKeywords.some((keyword) => messageText.toLowerCase().includes(keyword));
          if (hasGenerationRequest) {
            try {
              if (!process.env.TELEGRAM_BOT_TOKEN) {
                throw new Error("TELEGRAM_BOT_TOKEN not found in environment variables");
              }
              const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
              await fetch(`${telegramApiUrl}/sendMessage`, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json"
                },
                body: JSON.stringify({
                  chat_id: message.chat.id,
                  text: "\u{1F3A8} \u0413\u0435\u043D\u0435\u0440\u0438\u0440\u0443\u044E \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435, \u043E\u0436\u0438\u0434\u0430\u0439\u0442\u0435 ~30-60 \u0441\u0435\u043A\u0443\u043D\u0434..."
                })
              });
              logger?.info("\u{1F4DD} [Telegram Trigger] Generation status message sent");
            } catch (error) {
              logger?.error("\u{1F4DD} [Telegram Trigger] Error sending generation status message", {
                error: error instanceof Error ? error.message : String(error)
              });
            }
          }
          if (message.photo || message.video || message.document || message.voice || message.sticker || message.animation || message.video_note || message.audio) {
            logger?.info("\u{1F4DD} [Telegram Trigger] Media detected - skipping generation for media messages", {
              hasPhoto: !!message.photo,
              hasVideo: !!message.video,
              hasDocument: !!message.document,
              hasVoice: !!message.voice,
              hasSticker: !!message.sticker,
              hasAnimation: !!message.animation,
              hasVideoNote: !!message.video_note,
              hasAudio: !!message.audio
            });
            return;
          }
          if (!messageText || messageText.trim().length === 0) {
            logger?.info("\u{1F4DD} [Telegram Trigger] No text message - skipping generation");
            return;
          }
          logger?.info("\u{1F4DD} [Telegram Trigger] Text-only message detected - proceeding with generation", {
            textLength: messageText.length,
            hasMedia: false
          });
          try {
            const run = await mastra2.getWorkflow("telegramBotWorkflow").createRunAsync();
            await run.start({
              inputData: {
                message: messageText,
                fileIds: [],
                // Пустой массив - медиа не обрабатываем
                chatId: message.chat.id.toString(),
                userId: message.from?.id.toString() || "unknown",
                // Include Telegram user ID for rate limiting
                userName: message.from?.username || message.from?.first_name || "User",
                messageId: message.message_id.toString(),
                threadId: `telegram/${message.chat.id}`,
                chatType: message.chat.type
                // Передаем тип чата для корректных лимитов
              }
            });
          } catch (error) {
            logger?.error("\u{1F4DD} [Telegram Trigger] Error starting workflow", {
              error: error instanceof Error ? error.message : String(error),
              chatId: message.chat.id.toString()
            });
          }
        }
      })
    ]
  },
  logger: process.env.NODE_ENV === "production" ? new ProductionPinoLogger({
    name: "Mastra",
    level: "info"
  }) : new PinoLogger({
    name: "Mastra",
    level: "info"
  })
});
if (Object.keys(mastra.getWorkflows()).length > 1) {
  throw new Error("More than 1 workflows found. Currently, more than 1 workflows are not supported in the UI, since doing so will cause app state to be inconsistent.");
}
if (Object.keys(mastra.getAgents()).length > 1) {
  throw new Error("More than 1 agents found. Currently, more than 1 agents are not supported in the UI, since doing so will cause app state to be inconsistent.");
}

function generateReferralCode(userId) {
  const timestamp = Date.now().toString(36);
  const randomStr = Math.random().toString(36).substring(2, 8);
  const userHash = userId.slice(-4);
  return `${userHash}${timestamp}${randomStr}`.toUpperCase();
}
async function getOrCreateReferralCode(userId, logger) {
  logger?.info("\u{1F517} [Referral] Getting or creating referral code", { userId });
  try {
    const existing = await db.select({ referralCode: users.referral_code }).from(users).where(eq(users.user_id, userId)).limit(1);
    if (existing.length > 0 && existing[0].referralCode) {
      logger?.info("\u{1F517} [Referral] Found existing referral code", {
        userId,
        hasCode: true
      });
      return existing[0].referralCode;
    }
    let referralCode;
    let attempts = 0;
    const maxAttempts = 10;
    do {
      referralCode = generateReferralCode(userId);
      attempts++;
      const codeExists = await db.select({ user_id: users.user_id }).from(users).where(eq(users.referral_code, referralCode)).limit(1);
      if (codeExists.length === 0) {
        await db.update(users).set({ referral_code: referralCode }).where(eq(users.user_id, userId));
        logger?.info("\u{1F517} [Referral] Created and saved new referral code", {
          userId,
          attempts,
          codeLength: referralCode.length
        });
        return referralCode;
      }
      logger?.warn("\u{1F517} [Referral] Referral code collision, retrying", {
        userId,
        attempts,
        maxAttempts
      });
    } while (attempts < maxAttempts);
    throw new Error("Failed to generate unique referral code after maximum attempts");
  } catch (error) {
    logger?.error("\u{1F517} [Referral] Error getting or creating referral code", {
      userId,
      error: error instanceof Error ? error.message : String(error)
    });
    throw error;
  }
}
async function processReferral(referredUserId, referralCode, logger) {
  logger?.info("\u{1F517} [Referral] Processing referral", { referredUserId, referralCode: "***" });
  try {
    const referrer = await db.select({
      user_id: users.user_id
    }).from(users).where(eq(users.referral_code, referralCode)).limit(1);
    if (referrer.length === 0) {
      logger?.warn("\u{1F517} [Referral] Invalid referral code", { referredUserId, referralCode: "***" });
      return { success: false };
    }
    const referrerUserId = referrer[0].user_id;
    if (referrerUserId === referredUserId) {
      logger?.warn("\u{1F517} [Referral] Self-referral attempt blocked", {
        referredUserId,
        referralCode: "***"
      });
      return { success: false };
    }
    const existingReferral = await db.select({ id: referrals.id }).from(referrals).where(eq(referrals.referred_user_id, referredUserId)).limit(1);
    if (existingReferral.length > 0) {
      logger?.warn("\u{1F517} [Referral] User already referred", {
        referredUserId,
        referralCode: "***"
      });
      return { success: false };
    }
    await db.insert(referrals).values({
      referrer_user_id: referrerUserId,
      referred_user_id: referredUserId,
      referral_code: referralCode,
      created_at: /* @__PURE__ */ new Date()
    });
    logger?.info("\u{1F517} [Referral] Referral processed successfully", {
      referredUserId,
      referrerUserId,
      referralCode
    });
    return { success: true, referrerUserId };
  } catch (error) {
    logger?.error("\u{1F517} [Referral] Error processing referral", {
      referredUserId,
      referralCode,
      error: error instanceof Error ? error.message : String(error)
    });
    return { success: false };
  }
}
async function notifyAdminAboutReferral(referrerUserId, referredUserId, logger) {
  logger?.info("\u{1F514} [Referral] Sending admin notification", {
    referrerUserId,
    referredUserId
  });
  try {
    if (!process.env.TELEGRAM_BOT_TOKEN) {
      throw new Error("TELEGRAM_BOT_TOKEN not found in environment variables");
    }
    const referrerData = await db.select({ username: users.username }).from(users).where(eq(users.user_id, referrerUserId)).limit(1);
    const referredData = await db.select({ username: users.username }).from(users).where(eq(users.user_id, referredUserId)).limit(1);
    const referrerName = referrerData.length > 0 ? referrerData[0].username : `ID:${referrerUserId}`;
    const referredName = referredData.length > 0 ? referredData[0].username : `ID:${referredUserId}`;
    const adminUserId = "6913446846";
    const telegramApiUrl = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
    const message = `\u{1F389} *\u041D\u043E\u0432\u044B\u0439 \u0440\u0435\u0444\u0435\u0440\u0430\u043B!*

\u{1F464} \u041F\u0440\u0438\u0433\u043B\u0430\u0441\u0438\u043B: @${referrerName}
\u{1F195} \u041D\u043E\u0432\u044B\u0439 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C: @${referredName}

\u{1F4CA} \u0421\u0438\u0441\u0442\u0435\u043C\u0430 \u0440\u0435\u0444\u0435\u0440\u0430\u043B\u043E\u0432 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442!`;
    await fetch(`${telegramApiUrl}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: adminUserId,
        text: message,
        parse_mode: "Markdown"
      })
    });
    logger?.info("\u{1F514} [Referral] Admin notification sent successfully", {
      referrerUserId,
      referredUserId,
      referrerName,
      referredName
    });
  } catch (error) {
    logger?.error("\u{1F514} [Referral] Error sending admin notification", {
      referrerUserId,
      referredUserId,
      error: error instanceof Error ? error.message : String(error)
    });
  }
}

var referralUtils = /*#__PURE__*/Object.freeze({
  __proto__: null,
  generateReferralCode: generateReferralCode,
  getOrCreateReferralCode: getOrCreateReferralCode,
  notifyAdminAboutReferral: notifyAdminAboutReferral,
  processReferral: processReferral
});

export { mastra };
